package Interfaces;

import Util.ubicacionDB.Departamento;
import Util.ubicacionDB.Provincia;
import Util.ubicacionDB.Distrito;

import java.util.List;

public interface UbigeoRepository {

    List<Departamento> obtenerDepartamentos();
    List<Provincia> obtenerProvinciasPorDepartamento(String departamentoId);
    List<Distrito> obtenerDistritosPorProvincia(String provinciaId);
    String obtenerAbreviacionDepartamento(String departamentoId);


}
