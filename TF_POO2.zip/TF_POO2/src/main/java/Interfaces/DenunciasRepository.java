package Interfaces;

import Util.Denuncia.Denuncia;

public interface DenunciasRepository {

    void insertarDenuncia(String idDenuncia,Denuncia denuncia);

    void insertarDatosPersonales(String idDenuncia, Denuncia denuncia);

    void insertarUbicacion(String idDenuncia, Denuncia denuncia);

    void insertarDetallesDenuncia(String idDenuncia, Denuncia denuncia);

    String leerDenuncia(String idDenuncia);

    void updateDenuncia(Denuncia denuncia);

    void eliminarDenuncia(Denuncia denuncia);
}
