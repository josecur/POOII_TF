package Interfaces;

import javax.swing.*;
import java.awt.*;

public abstract class Controller {

    private static CardLayout homeLayout = new CardLayout();
    private static JPanel contenedor = new JPanel(homeLayout);

    public static void setLayout(CardLayout cardLayout, JPanel jPanel){
        homeLayout = cardLayout;
        contenedor = jPanel;

    }

    public abstract void run();


    public static void changeView(String name) {
        homeLayout.show(contenedor, name);
    }

}
