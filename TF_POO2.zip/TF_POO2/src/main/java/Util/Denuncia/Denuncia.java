package Util.Denuncia;

import Interfaces.NivelRiesgo;
import Interfaces.TipoDenuncia;

public class Denuncia {
    private int id;
    private TipoDenuncia tipoDenuncia;
    private DatosPersonales datosPersonales;
    private Ubicacion ubicacion;
    private DetallesDenuncia detallesDenuncia;
    private NivelRiesgo nivelRiesgo;

    public Denuncia(DetallesDenuncia detallesDenuncia, Ubicacion ubicacion,
                    DatosPersonales datosPersonales, TipoDenuncia tipoDenuncia) {
        this.detallesDenuncia = detallesDenuncia;
        this.ubicacion = ubicacion;
        this.datosPersonales = datosPersonales;
        this.tipoDenuncia = tipoDenuncia;

        calcularNivelRiesgo();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public TipoDenuncia getTipoDenuncia() {
        return tipoDenuncia;
    }

    public DatosPersonales getDatosPersonales() {
        return datosPersonales;
    }

    public Ubicacion getUbicacion() {
        return ubicacion;
    }

    public DetallesDenuncia getDetallesDenuncia() {
        return detallesDenuncia;
    }

    public NivelRiesgo getNivelRiesgo(){
        return nivelRiesgo;
    }

    public void setTipoDenuncia(TipoDenuncia tipoDenuncia) {
        this.tipoDenuncia = tipoDenuncia;
    }

    public void setDatosPersonales(DatosPersonales datosPersonales) {
        this.datosPersonales = datosPersonales;
    }

    public void setUbicacion(Ubicacion ubicacion) {
        this.ubicacion = ubicacion;
    }

    public void setDetallesDenuncia(DetallesDenuncia detallesDenuncia) {
        this.detallesDenuncia = detallesDenuncia;
    }

    public void calcularNivelRiesgo() {
        this.nivelRiesgo = tipoDenuncia.calcularRiesgo(this);
    }


}
