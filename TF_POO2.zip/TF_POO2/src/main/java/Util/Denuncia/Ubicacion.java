package Util.Denuncia;

public class Ubicacion {
    private String departamento;
    private String provincia;
    private String distirto;
    private String direccion;
    private String detallesAdicionales;

    public Ubicacion(String departamento, String provincia, String distirto,
                     String direccion, String detallesAdicionales) {
        this.departamento = departamento;
        this.provincia = provincia;
        this.distirto = distirto;
        this.direccion = direccion;
        this.detallesAdicionales = detallesAdicionales;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getDistirto() {
        return distirto;
    }

    public void setDistirto(String distirto) {
        this.distirto = distirto;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getDetallesAdicionales() {
        return detallesAdicionales;
    }

    public void setDetallesAdicionales(String detallesAdicionales) {
        this.detallesAdicionales = detallesAdicionales;
    }
}
