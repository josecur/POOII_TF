package Util;

public class StringUtil {
    public static String nullIfBlank(String value) {
        return (value == null || value.trim().isEmpty()) ? null : value;
    }
}
