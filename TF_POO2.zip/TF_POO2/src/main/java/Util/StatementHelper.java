package Util;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

public class StatementHelper {
    private final PreparedStatement ps;

    public StatementHelper(PreparedStatement ps) {
        this.ps = ps;
    }

    public void setString(int index, String value) throws SQLException {
        if (value != null) {
            ps.setString(index, value);
        } else {
            ps.setNull(index, Types.VARCHAR);
        }
    }

    public void setBoolean(int index, Boolean value) throws SQLException {
        if (value != null) {
            ps.setBoolean(index, value);
        } else {
            ps.setNull(index, Types.BIT);
        }
    }





}
