package Util.ubicacionDB;

public class Departamento {
    private String id;
    private String name;
    private String abbreviation;

    public Departamento(String id, String name, String abbreviation) {
        this.id = id;
        this.name = name;
        this.abbreviation = abbreviation;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    @Override
    public String toString() {
        return this.name;
    }

    public static Departamento fromString(String data){

        String[] partes = data.split("-");

        return new Departamento(partes[0],partes[1],partes[2]);

    }
}
