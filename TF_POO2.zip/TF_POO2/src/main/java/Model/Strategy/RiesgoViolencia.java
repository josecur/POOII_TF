package Model.Strategy;

import Interfaces.NivelRiesgo;
import Interfaces.RiesgoBehavior;
import Util.Denuncia.Denuncia;
import Util.Denuncia.DetallesDenuncia;

public class RiesgoViolencia implements RiesgoBehavior {
    @Override
    public NivelRiesgo evaluarRiesgo(Denuncia denuncia) {
        DetallesDenuncia detalles = denuncia.getDetallesDenuncia();

        if (detalles.isUsoDeObjetos() || detalles.isAgresores()){
            return NivelRiesgo.CRITICO;

        }else if (detalles.isHospitalizacion() || detalles.getGravedadHeridas().equals("Grave")){
            return NivelRiesgo.EXTREMO;

        }

        return NivelRiesgo.ALTO;
    }
}
