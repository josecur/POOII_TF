package Model.Strategy;

import Interfaces.NivelRiesgo;
import Interfaces.RiesgoBehavior;
import Util.Denuncia.Denuncia;
import Util.Denuncia.DetallesDenuncia;

public class RiesgoDomestica implements RiesgoBehavior {
    @Override
    public NivelRiesgo evaluarRiesgo(Denuncia denuncia) {
        DetallesDenuncia detalles = denuncia.getDetallesDenuncia();

        boolean frecuenciaE = detalles.getFrecuencia().equals("Frecuentemente") ||
                detalles.getFrecuencia().equals("Repetitivo");

        if (detalles.isMenoresInvolucrados() || frecuenciaE || detalles.isHospitalizacion()){

            return NivelRiesgo.EXTREMO;
        }

        return NivelRiesgo.CRITICO;
    }
}
