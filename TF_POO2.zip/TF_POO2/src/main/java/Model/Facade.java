package Model;

import Interfaces.DenunciasRepository;
import Interfaces.UbigeoRepository;
import Model.Repository.DenunciaRepository;
import Model.Repository.ProcedimientosRepository;
import Model.Repository.UbicacionRepository;
import Util.Denuncia.Denuncia;

public class Facade {
    private static final UbigeoRepository ubicacionRepo = new UbicacionRepository();
    private static final DenunciasRepository denunciaRepo = new DenunciaRepository();
    private static final ProcedimientosRepository procedimientosRepo = new ProcedimientosRepository();


    public static void facadeSistema(FlujoDenunciaModel flujo){
        //Se construye la Denuncia
        Denuncia denuncia = flujo.construirDenunciaFinal();

        //Se obtiene la abreviacion
        String abrr = ubicacionRepo.obtenerAbreviacionDepartamento(denuncia.getUbicacion().getDepartamento());

        //Se obtiene el id
        String id = procedimientosRepo.nuevoID(abrr);

        //se guarda la Denuncia en la BD
        denunciaRepo.insertarDenuncia(id,denuncia);
        denunciaRepo.insertarDatosPersonales(id,denuncia);
        denunciaRepo.insertarUbicacion(id,denuncia);
        denunciaRepo.insertarDetallesDenuncia(id,denuncia);

        //Seteamos el id en el flujo
        flujo.setId(id);
    }
}
