package View.DenunciaViews;

import Controller.DenunciaControllers.DatosPersonalesController;
import Interfaces.TipoDocumento;
import Interfaces.View;
import Util.FontUtil;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.text.ParseException;

public class DatosPersonalesView extends JPanel implements View {
    private DatosPersonalesController datosPersonalesController;
    private GridBagConstraints gbc;

    private JTextField txt_nombre;
    private JTextField txt_apellidoPaterno;
    private JTextField txt_apellidoMaterno;
    private JComboBox<TipoDocumento> cmb_tipoDocumento;
    private JFormattedTextField txt_idDocumento;
    private JFormattedTextField txt_numeroCelular;
    private JTextField txt_email;
    private JFormattedTextField txt_edad;

    private JButton btn_siguiente;
    private JButton btn_atras;



    public DatosPersonalesView(DatosPersonalesController datosPersonalesController){
        this.datosPersonalesController = datosPersonalesController;

        iniciarComponentes();

    }


    @Override
    public void iniciarComponentes() {
        make_frame();
        make_encabezado();
        make_nombreField();
        make_apellidoPaternoField();
        make_apellidoMaternoField();
        make_tipoDocumento();
        make_idDocumento();
        make_email();
        make_numeroCelular();
        make_edad();

        make_siguiente();
        make_atras();

    }

    private void make_frame() {
        setLayout(new GridBagLayout());
        setBackground(new Color(194, 190, 190));
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
    }

    private void make_encabezado(){
        JLabel icono = new JLabel(new ImageIcon(getClass().getResource("/assets/Shield.png")));
        JLabel titulo = new JLabel("DATOS PERSONALES");
        titulo.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",46f));
        titulo.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(new Color(194, 190, 190));
        headerPanel.add(icono);
        headerPanel.add(titulo);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 4;
        add(headerPanel, gbc);
        gbc.gridwidth = 1;
    }

    private void make_nombreField() {
        addLabel("Nombre:", 0, 1);
        txt_nombre = addTextField(1, 1, 3);
    }

    private void make_apellidoPaternoField() {
        addLabel("Apellido Paterno:", 0, 2);
        txt_apellidoPaterno = addTextField(1, 2, 1);
    }

    private void make_apellidoMaternoField() {
        addLabel("Apellido Materno:", 2, 2);
        txt_apellidoMaterno = addTextField(3, 2, 1);
    }

    private void make_tipoDocumento(){
        addLabel("Tipo Documento:", 0, 4);
        cmb_tipoDocumento = new JComboBox<>(TipoDocumento.values());
        cmb_tipoDocumento.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        cmb_tipoDocumento.setPreferredSize(new Dimension(300, 40));
        addComponent(cmb_tipoDocumento, 1, 4, 2);
    }

    private void make_idDocumento(){
        addLabel("N° Documento:", 0, 5);
        try {
            txt_idDocumento = new JFormattedTextField(new MaskFormatter("########"));
            txt_idDocumento.setFocusLostBehavior(JFormattedTextField.PERSIST);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        txt_idDocumento.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        txt_idDocumento.setPreferredSize(new Dimension(300, 40));
        txt_idDocumento.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        addComponent(txt_idDocumento, 1, 5, 2);
    }

    private void make_numeroCelular(){
        addLabel("Celular:", 0, 6);
        try {
            txt_numeroCelular = new JFormattedTextField(new MaskFormatter("###-###-###"));
            txt_numeroCelular.setFocusLostBehavior(JFormattedTextField.PERSIST);
        } catch (Exception e) {
            e.printStackTrace();
        }
        txt_numeroCelular.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        txt_numeroCelular.setPreferredSize(new Dimension(300, 40));
        txt_numeroCelular.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        addComponent(txt_numeroCelular, 1, 6, 1);
    }

    private void make_email() {
        addLabel("Email:", 0, 7);
        txt_email = addTextField(1, 7, 3);
    }

    private void make_edad(){
        addLabel("Edad:", 2, 6);
        try {
            txt_edad = new JFormattedTextField(new MaskFormatter("##"));
            txt_edad.setFocusLostBehavior(JFormattedTextField.PERSIST);
        } catch (Exception e) {
            e.printStackTrace();
        }
        txt_edad.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        txt_edad.setPreferredSize(new Dimension(100, 40));
        txt_edad.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        addComponent(txt_edad, 3, 6, 1);
    }

    private void make_siguiente(){
        btn_siguiente = new JButton("Siguiente");
        btn_siguiente.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));
        btn_siguiente.setBackground(Color.BLACK);
        btn_siguiente.setForeground(Color.WHITE);
        btn_siguiente.setFocusPainted(false);
        btn_siguiente.setPreferredSize(new Dimension(150, 45));
        btn_siguiente.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btn_siguiente.addActionListener(e -> {

                String nombre = txt_nombre.getText();
                String apellidoPaterno = txt_apellidoPaterno.getText();
                String apellidoMaterno = txt_apellidoMaterno.getText();
                TipoDocumento tipoDocumento = (TipoDocumento) cmb_tipoDocumento.getSelectedItem();
                String idDocumento = txt_idDocumento.getText().trim();
                String email = txt_email.getText();
                String celular = txt_numeroCelular.getText().replace("-", "").trim();
                String edad = txt_edad.getText().trim();

                datosPersonalesController.recolectarDatos(
                        nombre,
                        apellidoPaterno,
                        apellidoMaterno,
                        tipoDocumento,
                        idDocumento,
                        email,
                        celular,
                        edad
                );

        });

        gbc.anchor = GridBagConstraints.EAST;
        addComponent(btn_siguiente, 3, 9, 1);
    }

    private void make_atras(){
        btn_atras = new JButton("Atrás");
        btn_atras.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));
        btn_atras.setBackground(Color.BLACK);
        btn_atras.setForeground(Color.WHITE);
        btn_atras.setFocusPainted(false);
        btn_atras.setPreferredSize(new Dimension(150, 45));
        btn_atras.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btn_atras.addActionListener(e -> {
            datosPersonalesController.previousView();

        });

        gbc.anchor = GridBagConstraints.WEST;
        addComponent(btn_atras, 0, 9, 1);
    }


    //---------------------------------------------------------------

    private void addLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));
        label.setForeground(Color.BLACK);
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = 1;
        add(label, gbc);
    }

    private JTextField addTextField(int x, int y, int gridWidth) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        field.setPreferredSize(new Dimension(300, 40));
        field.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        addComponent(field, x, y, gridWidth);
        return field;
    }

    private void addComponent(JComponent comp, int x, int y, int gridWidth) {
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = gridWidth;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(comp, gbc);
    }



    public void clear_fields(){
        txt_nombre.setText("");
        txt_apellidoPaterno.setText("");
        txt_apellidoMaterno.setText("");
        cmb_tipoDocumento.setSelectedItem("");
        txt_idDocumento.setText("");
        txt_numeroCelular.setText("");
        txt_email.setText("");
        txt_edad.setText("");
    }

    public void show_error(String mensaje){
        JOptionPane.showMessageDialog(null,mensaje,"ERROR",JOptionPane.WARNING_MESSAGE);
    }


}
