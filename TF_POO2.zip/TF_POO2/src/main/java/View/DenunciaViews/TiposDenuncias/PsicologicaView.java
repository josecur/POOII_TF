package View.DenunciaViews.TiposDenuncias;

import Controller.DenunciaControllers.TiposDenuncias.PsicologicaController;
import Interfaces.View;
import Util.FontUtil;

import javax.swing.*;
import java.awt.*;

public class PsicologicaView extends JPanel implements View {
    private PsicologicaController psicologicaController;
    private GridBagConstraints gbc;

    private JTextField txt_victima;
    private JTextField txt_agresor;
    private JComboBox cmb_relacionAgresor;
    private JTextArea txt_descripcion;

    private JComboBox cmb_frecuencia;
    private JTextField txt_sintomas;
    private JRadioButton rdb_hospitalizacion_si;
    private JRadioButton rdb_hospitalizacion_no;

    public PsicologicaView(PsicologicaController psicologicaController){
        this.psicologicaController = psicologicaController;

        iniciarComponentes();
    }

    @Override
    public void iniciarComponentes() {
        make_frame();
        make_victima();
        make_agresor();
        make_relacionAgresor();
        make_frecuencia();
        make_sintomas();
        make_hospital();
        make_descripcion();
    }

    private void make_frame() {
        setLayout(new GridBagLayout());
        setBackground(Color.decode("#eeeeee"));
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
    }

    private void make_victima() {
        addLabel("Nombre de la víctima:", 0, 0);
        txt_victima = addTextField(1, 0, 1);
    }

    private void make_agresor() {
        addLabel("Nombre del agresor:", 0, 1);
        txt_agresor = addTextField(1, 1, 1);
    }

    private void make_relacionAgresor() {
        addLabel("Relación con el agresor:", 0, 2);
        cmb_relacionAgresor = new JComboBox<>(new String[]{
                "Ninguna", "Conocido/a", "Amistad", "Pareja"
        });
        cmb_relacionAgresor.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        addComponent(cmb_relacionAgresor, 1, 2, 1);
    }

    private void make_frecuencia() {
        addLabel("Frecuencia del acoso:", 0, 3);
        cmb_frecuencia = new JComboBox<>(new String[]{
                "Primera vez", "Ocasionalmente", "Frecuentemente", "Repetitivo"
        });
        cmb_frecuencia.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        addComponent(cmb_frecuencia, 1, 3, 1);
    }

    private void make_sintomas() {
        addLabel("Síntomas observados:", 0, 4);
        txt_sintomas = addTextField(1, 4, 1);
    }

    private void make_hospital() {
        addLabel("¿Requirió hospitalización?", 0, 5);
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        panel.setBackground(Color.decode("#eeeeee"));

        rdb_hospitalizacion_si = new JRadioButton("Sí");
        rdb_hospitalizacion_no = new JRadioButton("No");

        ButtonGroup grupo = new ButtonGroup();
        grupo.add(rdb_hospitalizacion_si);
        grupo.add(rdb_hospitalizacion_no);

        styleRadio(rdb_hospitalizacion_si);
        styleRadio(rdb_hospitalizacion_no);

        panel.add(rdb_hospitalizacion_si);
        panel.add(rdb_hospitalizacion_no);
        addComponent(panel, 1, 5, 1);
    }

    private void make_descripcion() {
        addLabel("Descripción de los hechos:", 0, 6);
        txt_descripcion = new JTextArea(6, 40);
        txt_descripcion.setLineWrap(true);
        txt_descripcion.setWrapStyleWord(true);
        txt_descripcion.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txt_descripcion.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        JScrollPane scroll = new JScrollPane(txt_descripcion);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scroll.setPreferredSize(new Dimension(600, 120));
        addComponent(scroll, 1, 6, 3);
    }



    public void reset() {
        txt_victima.setText("");
        txt_agresor.setText("");
        cmb_relacionAgresor.setSelectedIndex(0);
        cmb_frecuencia.setSelectedIndex(0);
        txt_descripcion.setText("");
        txt_sintomas.setText("");
        rdb_hospitalizacion_si.setSelected(false);
        rdb_hospitalizacion_no.setSelected(false);
    }


    //-----------------------------------------------------------------------------------------------------

    private void addLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf", 15f));
        label.setForeground(Color.BLACK);
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = 1;
        add(label, gbc);
    }

    private void styleRadio(JRadioButton radio) {
        radio.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        radio.setBackground(Color.decode("#eeeeee"));
    }

    private JTextField addTextField(int x, int y, int gridWidth) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        field.setPreferredSize(new Dimension(300, 40));
        field.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        addComponent(field, x, y, gridWidth);
        return field;
    }

    private void addComponent(JComponent comp, int x, int y, int gridWidth) {
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = gridWidth;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(comp, gbc);
    }

    public String getVictima(){
        return txt_victima.getText();
    }

    public String getAgresor(){
        return txt_agresor.getText();
    }

    public String getRelacionAgresor(){
        return (String)cmb_relacionAgresor.getSelectedItem();
    }

    public String getDescripcion(){
        return txt_descripcion.getText();
    }

    public String getFrecuencia(){
        return (String)cmb_frecuencia.getSelectedItem();
    }

    public String getSintomas(){
        return txt_sintomas.getText();
    }

    public Boolean getHospitalizacion(){
        return rdb_hospitalizacion_si.isSelected();
    }
}
