package Controller;

import Controller.DenunciaControllers.*;
import Interfaces.Controller;
import Model.FlujoDenunciaModel;
import View.DenunciaViews.*;
import View.HomeView;
import View.PrincipalView;

import javax.swing.*;
import java.util.HashMap;
import java.util.Map;


public class HomeController extends Controller {
    private FlujoDenunciaModel flujoDenuncia = new FlujoDenunciaModel();

    private HomeView homeView;

    private Map<String, JPanel> views = new HashMap<>();

    private TerminosYCondicionesController terminosYCondicionesController = new TerminosYCondicionesController(flujoDenuncia);
    private UbigeoController ubigeoController = new UbigeoController(flujoDenuncia);
    private DatosPersonalesController datosPersonalesController = new DatosPersonalesController(flujoDenuncia);
    private DenunciaFormController denunciaFormController = new DenunciaFormController(flujoDenuncia);
    private DenunciaResumenController denunciaResumenController = new DenunciaResumenController(flujoDenuncia);


    private PrincipalController principalController = new PrincipalController();



    @Override
    public void run() {
        terminosYCondicionesController.run();
        principalController.run();
        ubigeoController.run();
        datosPersonalesController.run();
        denunciaFormController.run();
        denunciaResumenController.run();


        HomeView homeView = new HomeView(this);
        homeView.setVisible(true);

        setPrincipalView();
    }

    public void setPrincipalView(){
        changeView("Pantalla Principal");
    }

    public TerminosYCondicionesView getTerminosYCondicionesView(){
        return terminosYCondicionesController.getView();
    }

    public UbigeoView getUbigeoView(){
        return ubigeoController.getView();
    }

    public PrincipalView getPrincipalView(){
        return principalController.getView();
    }

    public DatosPersonalesView getDatosPersonalesView(){
        return datosPersonalesController.getView();
    }

    public DenunciaFormView getDenunciaFormView(){ return denunciaFormController.getView(); }

    public DenunciaResumenView getDenunciaResumenView(){ return denunciaResumenController.getView(); }



}

