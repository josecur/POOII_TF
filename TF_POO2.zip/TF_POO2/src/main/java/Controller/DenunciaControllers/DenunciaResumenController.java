package Controller.DenunciaControllers;

import Interfaces.Controller;
import Interfaces.MailSender;
import Model.FlujoDenunciaModel;
import Model.Repository.DenunciaRepository;
import View.DenunciaViews.DenunciaResumenView;

public class DenunciaResumenController extends Controller {
    private DenunciaRepository denunciaRepository = new DenunciaRepository();
    private DenunciaResumenView denunciaResumenView;
    private FlujoDenunciaModel flujoDenunciaModel;

    public DenunciaResumenController(FlujoDenunciaModel flujoDenunciaModel){
        this.flujoDenunciaModel = flujoDenunciaModel;

    }


    @Override
    public void run() {
        denunciaResumenView = new DenunciaResumenView(this);
        flujoDenunciaModel.subscribe(denunciaResumenView);
    }

    public void siguientelogic(){

        try{
            MailSender.enviarCorreo(flujoDenunciaModel.getDatosPersonales().getEmail(),
                    "Envio de la Denuncia " + flujoDenunciaModel.getTipoDenuncia().getNombre(),
                    getResumen());

            nextView();
        }catch (Exception e){
            denunciaResumenView.show_error("Error al envia el correo");
        }
    }

    public String getResumen(){
        return denunciaRepository.leerDenuncia(flujoDenunciaModel.getId());
    }

    public String getDenunciaID(){
        return flujoDenunciaModel.getId();
    }

    public void nextView(){
        flujoDenunciaModel.limpiar();
        changeView("Pantalla Principal");
    }

    public void previousView(){
        changeView("Denuncia Formulario");
    }

    public DenunciaResumenView getView() {
        return denunciaResumenView;
    }
}
