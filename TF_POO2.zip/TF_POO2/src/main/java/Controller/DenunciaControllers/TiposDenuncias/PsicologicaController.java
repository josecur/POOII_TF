package Controller.DenunciaControllers.TiposDenuncias;

import Interfaces.ControllerForm;
import Model.DetallesDenunciaBuilder;
import View.DenunciaViews.TiposDenuncias.PsicologicaView;

public class PsicologicaController implements ControllerForm {
    private PsicologicaView psicologicaView;


    @Override
    public void run() {
        psicologicaView = new PsicologicaView(this);
    }


    public DetallesDenunciaBuilder recolectarInfo( ) {

        return new DetallesDenunciaBuilder()
                .victima(psicologicaView.getVictima())
                .agresor(psicologicaView.getAgresor())
                .relacionAgresor(psicologicaView.getRelacionAgresor())

                .frecuencia(psicologicaView.getFrecuencia())
                .sintomas(psicologicaView.getSintomas())
                .hospitalizacion(psicologicaView.getHospitalizacion())
                .descripcion(psicologicaView.getDescripcion());
    }

    public PsicologicaView getView(){
        return psicologicaView;
    }
}
