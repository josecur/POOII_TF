package Controller.DenunciaControllers.TiposDenuncias;

import Interfaces.ControllerForm;
import Model.DetallesDenunciaBuilder;
import View.DenunciaViews.TiposDenuncias.AbusoSexualView;

public class AbusoSexualController implements ControllerForm {
    private AbusoSexualView abusoSexualView;

    @Override
    public void run() {
        abusoSexualView = new AbusoSexualView(this);
    }

    public DetallesDenunciaBuilder recolectarInfo() {
        return new DetallesDenunciaBuilder()
                .victima(abusoSexualView.getVictima())
                .agresores(abusoSexualView.getAgresores())
                .agresor(abusoSexualView.getAgresor())
                .relacionAgresor(abusoSexualView.getRelacionAgresor())

                .testigos(abusoSexualView.getTestigos())
                .sintomas(abusoSexualView.getSintomas())
                .hospitalizacion(abusoSexualView.getHospitalizacion())
                .descripcion(abusoSexualView.getDescripcion());
    }

    public AbusoSexualView getView(){
        return abusoSexualView;
    }

    public void reset_fields(){
        abusoSexualView.reset();
    }
}
