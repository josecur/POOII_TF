package Controller.DenunciaControllers;

import Controller.DenunciaControllers.TiposDenuncias.*;
import Interfaces.Controller;
import Interfaces.TipoDenuncia;
import Model.DenunciaFormModel;
import Model.DetallesDenunciaBuilder;
import Model.Facade;
import Model.FlujoDenunciaModel;
import Util.Denuncia.DetallesDenuncia;
import View.DenunciaViews.DenunciaFormView;
import View.DenunciaViews.TiposDenuncias.*;


public class DenunciaFormController extends Controller {
    private DenunciaFormView denunciaFormView;
    private DenunciaFormModel denunciaFormModel = new DenunciaFormModel();
    private FlujoDenunciaModel flujoDenuncia;

    private AbusoSexualController abusoSexualController = new AbusoSexualController();
    private AcosoSexualController acosoSexualController = new AcosoSexualController();
    private AcosoController acosoController = new AcosoController();
    private DomesticaController domesticaController = new DomesticaController();
    private PsicologicaController psicologicaController = new PsicologicaController();
    private ViolenciaController violenciaController = new ViolenciaController();

    public DenunciaFormController(FlujoDenunciaModel flujoDenuncia) {
        this.flujoDenuncia = flujoDenuncia;
    }

    @Override
    public void run() {

        abusoSexualController.run();
        acosoController.run();
        acosoSexualController.run();
        domesticaController.run();
        psicologicaController.run();
        violenciaController.run();

        denunciaFormView = new DenunciaFormView(this);
    }

    private DetallesDenunciaBuilder creardetallesDenuncia(TipoDenuncia tipoDenuncia){
        DetallesDenunciaBuilder a = null;

        switch (tipoDenuncia) {
            case ABUSO_SEXUAL -> a = abusoSexualController.recolectarInfo();

            case ACOSO_SEXUAL -> a = acosoSexualController.recolectarInfo();

            case ACOSO -> a = acosoController.recolectarInfo();

            case DOMESTICA -> a = domesticaController.recolectarInfo();

            case PSICOLOGICA -> a = psicologicaController.recolectarInfo();

            case VIOLENCIA -> a = violenciaController.recolectarInfo();

        }
        return a;
    }

    public void recolectarDatos(TipoDenuncia tipoDenuncia, String fecha, String hora){
        try {
            DetallesDenunciaBuilder denunciaBuilder = creardetallesDenuncia(tipoDenuncia);
            DetallesDenuncia denuncia = denunciaFormModel.crearDetallesDenuncia(denunciaBuilder, fecha, hora);

            flujoDenuncia.setDetallesDenuncia(denuncia);
            flujoDenuncia.setTipoDenuncia(tipoDenuncia);
            Facade.facadeSistema(flujoDenuncia);


            denunciaFormView.show_confirmation();
            nextView();

        } catch (IllegalArgumentException e) {
            denunciaFormView.show_error(e.getMessage());
        }
    }




    public void changeView_tipoDenuncia(String nombre){
        for (TipoDenuncia tipo : TipoDenuncia.values()) {
            if (tipo.getNombre().equals(nombre)) {

                denunciaFormView.mostrarPanelDenuncia(tipo.name());
                break;
            }
        }
    }

    public void resetAll(){
        abusoSexualController.reset_fields();
    }

    public void nextView(){
        changeView("Resumen Denuncia");
    }

    public void previousView(){
        changeView("Ubigeo");
    }

    public DenunciaFormView getView() {
        return denunciaFormView;
    }

    public AbusoSexualView getAbusoSexualView() { return abusoSexualController.getView();}
    public AcosoSexualView getAcosoSexualView() { return acosoSexualController.getView();}
    public AcosoView getAcosoView() { return acosoController.getView();}
    public DomesticaView getDomesticaView() { return domesticaController.getView();}
    public PsicologicaView getPsicologicaView() { return psicologicaController.getView(); }
    public ViolenciaView getViolenciaView() { return violenciaController.getView(); }


}
