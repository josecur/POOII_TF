package Controller.DenunciaControllers.TiposDenuncias;

import Controller.DenunciaControllers.DenunciaFormController;
import Interfaces.ControllerForm;
import Model.DenunciaFormModel;
import Model.DetallesDenunciaBuilder;
import Util.Denuncia.DetallesDenuncia;
import View.DenunciaViews.TiposDenuncias.AbusoSexualView;

public class AbusoSexualController implements ControllerForm {
    private AbusoSexualView abusoSexualView;

    @Override
    public void run() {
        abusoSexualView = new AbusoSexualView(this);
    }

    public DetallesDenunciaBuilder recolectarInfo() {
        System.out.println(abusoSexualView.getAgresor());
        System.out.println(abusoSexualView.getAgresor());
        System.out.println(abusoSexualView.getSintomas());
        return new DetallesDenunciaBuilder()
                .victima(abusoSexualView.getVictima())
                .agresores(abusoSexualView.getAgresores())
                .agresor(abusoSexualView.getAgresor())
                .relacionAgresor(abusoSexualView.getRelacionAgresor())

                .testigos(abusoSexualView.getTestigos())
                .sintomas(abusoSexualView.getSintomas())
                .hospitalizacion(abusoSexualView.getHospitalizacion())
                .descripcion(abusoSexualView.getDescripcion());
    }

    public AbusoSexualView getView(){
        return abusoSexualView;
    }

    public void reset_fields(){
        abusoSexualView.reset();
    }
}
