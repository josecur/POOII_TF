package Controller.DenunciaControllers.TiposDenuncias;

import Controller.DenunciaControllers.DenunciaFormController;
import Interfaces.ControllerForm;
import Model.DetallesDenunciaBuilder;
import Util.Denuncia.DetallesDenuncia;
import View.DenunciaViews.TiposDenuncias.ViolenciaView;

public class ViolenciaController implements ControllerForm {
    private ViolenciaView violenciaView;

    @Override
    public void run() {
        violenciaView = new ViolenciaView(this);
    }


    public DetallesDenunciaBuilder recolectarInfo() {

        return new DetallesDenunciaBuilder()
                .victima(violenciaView.getVictima())
                .agresores(violenciaView.getAgresores())
                .agresor(violenciaView.getAgresor())
                .relacionAgresor(violenciaView.getRelacionAgresor())

                .testigos(violenciaView.getTestigos())
                .usoDeObjetos(violenciaView.getUsoDeObjetos())
                .objetos(violenciaView.getObjetos())
                .heridas(violenciaView.getHeridas())
                .gravedadHeridas(violenciaView.getGravedadHeridas())
                .hospitalizacion(violenciaView.getHospitalizacion())
                .descripcion(violenciaView.getDescripcion());
    }

    public ViolenciaView getView(){
        return violenciaView;
    }
}
