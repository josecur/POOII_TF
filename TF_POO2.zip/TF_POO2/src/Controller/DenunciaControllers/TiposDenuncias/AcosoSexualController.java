package Controller.DenunciaControllers.TiposDenuncias;

import Controller.DenunciaControllers.DenunciaFormController;
import Interfaces.ControllerForm;
import Model.DetallesDenunciaBuilder;
import Util.Denuncia.DetallesDenuncia;
import View.DenunciaViews.TiposDenuncias.AcosoSexualView;

public class AcosoSexualController implements ControllerForm {
    private AcosoSexualView acosoSexualView;

    @Override
    public void run() {
        acosoSexualView = new AcosoSexualView(this);
    }


    public DetallesDenunciaBuilder recolectarInfo() {


        return new DetallesDenunciaBuilder()
                .victima(acosoSexualView.getVictima())
                .agresor(acosoSexualView.getAgresor())
                .relacionAgresor(acosoSexualView.getRelacionAgresor())

                .testigos(acosoSexualView.getTestigos())
                .frecuencia(acosoSexualView.getFrecuencia())
                .descripcion(acosoSexualView.getDescripcion());
    }

    public AcosoSexualView getView(){
        return acosoSexualView;
    }
}
