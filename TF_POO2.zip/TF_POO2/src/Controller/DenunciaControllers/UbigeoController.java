package Controller.DenunciaControllers;

import Interfaces.Controller;

import Model.FlujoDenunciaModel;
import Model.Repository.UbicacionRepository;
import Model.UbigeoModel;
import Util.Denuncia.Ubicacion;
import Util.ubicacionDB.Departamento;
import Util.ubicacionDB.Distrito;
import Util.ubicacionDB.Provincia;
import View.DenunciaViews.UbigeoView;

import java.util.List;

public class UbigeoController extends Controller {
    private FlujoDenunciaModel flujoDenuncia;
    private UbicacionRepository ubicacionRepository = new UbicacionRepository();
    private UbigeoModel ubigeoModel = new UbigeoModel();
    private UbigeoView ubigeoView;

    public UbigeoController(FlujoDenunciaModel flujoDenuncia) {
        this.flujoDenuncia = flujoDenuncia;
    }

    @Override
    public void run() {
        ubigeoView = new UbigeoView(this);

    }

    public List<Departamento> fill_Departamentos(){
        return ubicacionRepository.obtenerDepartamentos();
    }

    public List<Provincia> fill_Provincias(String idDepartamento){
        return ubicacionRepository.obtenerProvinciasPorDepartamento(idDepartamento);
    }

    public List<Distrito> fill_Distritos(String idProvincia){
        return ubicacionRepository.obtenerDistritosPorProvincia(idProvincia);
    }

    public void recolectarDatos(Departamento departamento, Provincia provincia, Distrito distrito ,
                                String direccion, String detalles){

        if (departamento == null || provincia == null || distrito == null) {
            ubigeoView.show_error("Complete la selección de departamento, provincia y distrito.");
            return;
        }

        try {
            Ubicacion ubi = ubigeoModel.crearUbigeo(
                    departamento.getName(),
                    provincia.getName(),
                    distrito.getName(),
                    direccion,
                    detalles);

            flujoDenuncia.setUbicacion(ubi);
            nextView();

        } catch (IllegalArgumentException e) {
            ubigeoView.show_error(e.getMessage());
        }

    }

    public void nextView(){
        changeView("Denuncia Formulario");
    }

    public void previousView(){
        changeView("Datos Personales");
    }

    public void cleanView() { ubigeoView.clear_fields();}


    public UbigeoView getView() {
        return ubigeoView;
    }
}
