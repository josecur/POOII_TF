package Controller.DenunciaControllers;

import Interfaces.Controller;
import Model.FlujoDenunciaModel;
import Model.Repository.DenunciaRepository;
import View.DenunciaViews.DenunciaResumenView;

public class DenunciaResumenController extends Controller {
    private DenunciaRepository denunciaRepository = new DenunciaRepository();
    private DenunciaResumenView denunciaResumenView;
    private FlujoDenunciaModel flujoDenunciaModel;

    public DenunciaResumenController(FlujoDenunciaModel flujoDenunciaModel){
        this.flujoDenunciaModel = flujoDenunciaModel;

    }


    @Override
    public void run() {
        denunciaResumenView = new DenunciaResumenView(this);
        flujoDenunciaModel.subscribe(denunciaResumenView);
    }


    public String getResumen(){
        return denunciaRepository.leerDenuncia(flujoDenunciaModel.getId());
    }

    public String getDenunciaID(){
        return flujoDenunciaModel.getId();
    }

    public void nextView(){
        flujoDenunciaModel.limpiar();
        changeView("Pantalla Principal");
    }

    public void previousView(){
        changeView("Denuncia Formulario");
    }

    public DenunciaResumenView getView() {
        return denunciaResumenView;
    }
}
