package View;

import Controller.PrincipalController;
import Interfaces.View;

import javax.swing.*;
import java.awt.*;

public class PrincipalView extends JPanel implements View {
    private final PrincipalController principalController;

    private ScrollPane vistaPrincipal = new ScrollPane();
    private Button btn_denuncias;

    public PrincipalView(PrincipalController principalController) {
        this.principalController = principalController;

        iniciarComponentes();
    }

    @Override
    public void iniciarComponentes() {

    }
}
