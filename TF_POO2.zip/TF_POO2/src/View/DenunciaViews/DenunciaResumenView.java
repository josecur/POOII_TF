package View.DenunciaViews;

import Controller.DenunciaControllers.DenunciaResumenController;
import Interfaces.Listener;
import Interfaces.View;
import Util.FontUtil;

import javax.swing.*;
import java.awt.*;

public class DenunciaResumenView extends JPanel implements View, Listener {
    private DenunciaResumenController denunciaResumenController;
    private GridBagConstraints gbc;

    private JButton btn_siguiente;
    private JButton btn_atras;
    private JTextArea txtA_resumenArea;
    private JCheckBox chk_observerEmail;
    private JCheckBox chk_observerNumero;
    private JCheckBox chk_enviarEmail;
    private JCheckBox chk_enviarNumero;


    public DenunciaResumenView(DenunciaResumenController denunciaResumenController){
        this.denunciaResumenController = denunciaResumenController;
        iniciarComponentes();
    }

    @Override
    public void iniciarComponentes() {
        make_frame();
        make_encabezado();
        make_resumenArea();
        make_chkObserverEmail();
        make_chkObserverCelular();
        make_chkEnviarEmail();
        make_chkEnviarCelular();
        make_siguiente();
        make_atras();

    }

    private void make_frame(){
        setLayout(new GridBagLayout());
        setBackground(new Color(194, 190, 190));
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
    }

    private void make_encabezado(){
        JLabel icono = new JLabel(new ImageIcon("src/assets/Shield.png"));
        JLabel titulo = new JLabel("RESUMEN");
        titulo.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",46f));
        titulo.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(new Color(194, 190, 190));
        headerPanel.add(icono);
        headerPanel.add(titulo);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        add(headerPanel, gbc);
        gbc.gridwidth = 3;
    }

    private void make_resumenArea(){
        txtA_resumenArea = new JTextArea(10, 40);
        txtA_resumenArea.setFont(new Font("Tahoma", Font.ITALIC, 20));
        txtA_resumenArea.setLineWrap(true);
        txtA_resumenArea.setWrapStyleWord(true);
        txtA_resumenArea.setEditable(false);

        JScrollPane scroll = new JScrollPane(txtA_resumenArea);
        scroll.setPreferredSize(new Dimension(600, 300));
        addComponent(scroll, 0, 1, 3);

    }

    private void make_chkObserverEmail() {
        chk_observerEmail = new JCheckBox("Notificar observador por Email");
        chk_observerEmail.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",16f));
        chk_observerEmail.setBackground(getBackground());
        addComponent(chk_observerEmail, 0, 2, 1);
    }

    private void make_chkObserverCelular() {
        chk_observerNumero = new JCheckBox("Notificar observador por Número");
        chk_observerNumero.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",16f));
        chk_observerNumero.setBackground(getBackground());
        addComponent(chk_observerNumero, 0, 3, 1);
    }

    private void make_chkEnviarEmail() {
        chk_enviarEmail = new JCheckBox("Enviar resumen al Email del denunciante");
        chk_enviarEmail.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",16f));
        chk_enviarEmail.setBackground(getBackground());
        addComponent(chk_enviarEmail, 2, 2, 1);
    }

    private void make_chkEnviarCelular() {
        chk_enviarNumero = new JCheckBox("Enviar resumen al Celular del denunciante");
        chk_enviarNumero.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",16f));
        chk_enviarNumero.setBackground(getBackground());
        addComponent(chk_enviarNumero, 2, 3, 1);
    }


    private void clear_fields(){
        chk_observerEmail.setSelected(false);
        chk_observerNumero.setSelected(false);
        chk_enviarEmail.setSelected(false);
        chk_enviarNumero.setSelected(false);
    }



    private void make_siguiente(){
        btn_siguiente = new JButton("Siguiente");
        btn_siguiente.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));
        btn_siguiente.setBackground(Color.BLACK);
        btn_siguiente.setForeground(Color.WHITE);
        btn_siguiente.setFocusPainted(false);
        btn_siguiente.setPreferredSize(new Dimension(150, 45));
        btn_siguiente.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btn_siguiente.addActionListener(e -> {
            denunciaResumenController.nextView();
        });

        gbc.anchor = GridBagConstraints.EAST;
        addComponent(btn_siguiente, 2, 5, 1);
    }

    private void make_atras(){
        btn_atras = new JButton("Atras");
        btn_atras.setFont(FontUtil.loadFont("/assets/jersey-15-latin-400-normal.ttf",30f));
        btn_atras.setBackground(Color.BLACK);
        btn_atras.setForeground(Color.WHITE);
        btn_atras.setFocusPainted(false);
        btn_atras.setPreferredSize(new Dimension(150, 45));
        btn_atras.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btn_atras.addActionListener(e -> {
            denunciaResumenController.previousView();
        });

        gbc.anchor = GridBagConstraints.WEST;
        addComponent(btn_atras, 0, 5, 1);
    }


    //------------------------------------------------------

    private void addComponent(JComponent comp, int x, int y, int gridWidth) {
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = gridWidth;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(comp, gbc);
    }

    @Override
    public void update(String evento) {
        if (evento.equals("IDSET")) {
            txtA_resumenArea.setText(denunciaResumenController.getResumen());
        }
    }
}
