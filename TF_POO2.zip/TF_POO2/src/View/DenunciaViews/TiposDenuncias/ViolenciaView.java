package View.DenunciaViews.TiposDenuncias;

import Controller.DenunciaControllers.TiposDenuncias.ViolenciaController;
import Interfaces.View;

import javax.swing.*;

public class ViolenciaView extends JPanel implements View {
    private ViolenciaController violenciaController;

    private JTextField txt_victima;
    private JTextField txt_agresor;
    private JComboBox cmb_relacionAgresor;
    private JTextField txt_descripcion;

    private JRadioButton rdb_agresores_si;
    private JRadioButton rdb_agresores_no;
    private JRadioButton rdb_testigos_si;
    private JRadioButton rdb_testigos_no;
    private JRadioButton rdb_usoDeObjetos_si;
    private JRadioButton rdb_usoDeObjetos_no;
    private JTextField txt_objetos;
    private JTextField txt_heridas;
    private JComboBox cmb_gravedadHeridas;
    private JRadioButton rdb_hospitalizacion_si;
    private JRadioButton rdb_hospitalizacion_no;

    public ViolenciaView(ViolenciaController violenciaController){
        this.violenciaController = violenciaController;

        iniciarComponentes();
    }

    @Override
    public void iniciarComponentes() {

    }

    private void make_frame(){

    }

    private void make_victima(){

    }

    private void make_agresor(){

    }

    private void make_relacionAgresor(){

    }

    private void make_descripcion(){

    }

    private void make_agresores(){

    }

    private void make_testigos(){

    }

    private void make_usoDeObjetos(){

    }

    private void make_objetos(){

    }

    private void make_gravedadHeridas(){

    }

    private void make_hospitalizacion(){

    }

    public String getVictima(){
        return txt_victima.getText();
    }

    public String getAgresor(){
        return txt_agresor.getText();
    }

    public String getRelacionAgresor(){
        return (String)cmb_relacionAgresor.getSelectedItem();
    }

    public String getDescripcion(){
        return txt_descripcion.getText();
    }

    public Boolean getAgresores(){
        return rdb_agresores_si.isSelected();
    }

    public String getGravedadHeridas(){
        return (String)cmb_gravedadHeridas.getSelectedItem();
    }

    public Boolean getHospitalizacion(){
        return rdb_hospitalizacion_si.isSelected();
    }

    public String getHeridas(){
        return  txt_heridas.getText();
    }

    public String getObjetos(){
        return txt_objetos.getText();
    }

    public Boolean getUsoDeObjetos(){
        return rdb_usoDeObjetos_si.isSelected();
    }

    public Boolean getTestigos(){
        return rdb_testigos_si.isSelected();
    }
}
