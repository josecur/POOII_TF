package View.DenunciaViews.TiposDenuncias;

import Controller.DenunciaControllers.TiposDenuncias.AcosoSexualController;
import Interfaces.View;

import javax.swing.*;

public class AcosoSexualView extends JPanel implements View {
    private AcosoSexualController acosoSexualController;

    private JTextField txt_victima;
    private JTextField txt_agresor;
    private JComboBox cmb_relacionAgresor;
    private JTextField txt_descripcion;

    private JRadioButton rdb_testigos_si;
    private JRadioButton rdb_testigos_no;
    private JComboBox cmb_frecuencia;

    public AcosoSexualView(AcosoSexualController acosoSexualController){
        this.acosoSexualController = acosoSexualController;

        iniciarComponentes();
    }

    @Override
    public void iniciarComponentes() {

    }

    private void make_frame(){

    }

    private void make_victima(){

    }

    private void make_agresor(){

    }

    private void make_relacionAgresor(){

    }

    private void make_descripcion(){

    }

    private void make_frecuencia(){

    }

    private void make_testigos(){

    }

    public String getVictima(){
        return txt_victima.getText();
    }

    public String getAgresor(){
        return txt_agresor.getText();
    }

    public String getRelacionAgresor(){
        return (String)cmb_relacionAgresor.getSelectedItem();
    }

    public Boolean getTestigos(){
        return rdb_testigos_si.isSelected();
    }

    public String getFrecuencia(){
        return (String)cmb_frecuencia.getSelectedItem();
    }

    public String getDescripcion(){
        return txt_descripcion.getText();
    }

}
