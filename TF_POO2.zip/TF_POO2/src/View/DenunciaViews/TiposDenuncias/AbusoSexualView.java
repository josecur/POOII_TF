package View.DenunciaViews.TiposDenuncias;

import Controller.DenunciaControllers.TiposDenuncias.AbusoSexualController;
import Interfaces.View;

import javax.swing.*;
import java.awt.*;

public class AbusoSexualView extends JPanel implements View {
    private AbusoSexualController abusoSexualController;
    private GridBagConstraints gbc;


    private JTextField txt_victima;
    private JTextField txt_agresor;
    private JComboBox cmb_relacionAgresor;
    private JTextField txt_descripcion;

    private JRadioButton rdb_agresores_si;
    private JRadioButton rdb_agresores_no;
    private JRadioButton rdb_testigos_si;
    private JRadioButton rdb_testigos_no;
    private JTextField txt_sintomas;
    private JRadioButton rdb_hospitalizacion_si;
    private JRadioButton rdb_hospitalizacion_no;


    public AbusoSexualView(AbusoSexualController abusoSexualController){
        this.abusoSexualController = abusoSexualController;

        iniciarComponentes();
    }

    @Override
    public void iniciarComponentes() {
        make_frame();
        equide();
    }

    private void make_frame() {
        setLayout(new GridBagLayout());
        gbc = new GridBagConstraints();
    }

    private void equide(){


            gbc.insets = new Insets(10, 10, 10, 10);
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.anchor = GridBagConstraints.WEST;

            int y = 0;

            // Campo: Nombre de la víctima
            gbc.gridx = 0;
            gbc.gridy = y;
            add(new JLabel("Nombre de la víctima:"), gbc);

            txt_victima = new JTextField(20);
            gbc.gridx = 1;
            add(txt_victima, gbc);
            y++;

            // Campo: ¿Conoce a los agresores?
            gbc.gridx = 0;
            gbc.gridy = y;
            add(new JLabel("¿Conoce a los agresores?"), gbc);

            JPanel panelAgresores = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
            rdb_agresores_si = new JRadioButton("Sí");
            rdb_agresores_no = new JRadioButton("No");
            ButtonGroup bgAgresores = new ButtonGroup();
            bgAgresores.add(rdb_agresores_si);
            bgAgresores.add(rdb_agresores_no);
            panelAgresores.add(rdb_agresores_si);
            panelAgresores.add(rdb_agresores_no);

            gbc.gridx = 1;
            add(panelAgresores, gbc);
            y++;

            // Campo: Nombre del agresor
            gbc.gridx = 0;
            gbc.gridy = y;
            add(new JLabel("Nombre del agresor:"), gbc);

            txt_agresor = new JTextField(20);
            gbc.gridx = 1;
            add(txt_agresor, gbc);
            y++;

            // Campo: Relación con el agresor
            gbc.gridx = 0;
            gbc.gridy = y;
            add(new JLabel("Relación con el agresor:"), gbc);

            cmb_relacionAgresor = new JComboBox<>(new String[]{
                    "Ninguna", "Conocido/a", "Amistad", "Pareja"
            });
            gbc.gridx = 1;
            add(cmb_relacionAgresor, gbc);
            y++;

            // Campo: ¿Hubo testigos?
            gbc.gridx = 0;
            gbc.gridy = y;
            add(new JLabel("¿Hubo testigos?"), gbc);

            JPanel panelTestigos = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
            rdb_testigos_si = new JRadioButton("Sí");
            rdb_testigos_no = new JRadioButton("No");
            ButtonGroup bgTestigos = new ButtonGroup();
            bgTestigos.add(rdb_testigos_si);
            bgTestigos.add(rdb_testigos_no);
            panelTestigos.add(rdb_testigos_si);
            panelTestigos.add(rdb_testigos_no);

            gbc.gridx = 1;
            add(panelTestigos, gbc);
            y++;

            // Campo: Síntomas
            gbc.gridx = 0;
            gbc.gridy = y;
            add(new JLabel("Síntomas observados:"), gbc);

            txt_sintomas = new JTextField(30);
            gbc.gridx = 1;
            add(txt_sintomas, gbc);
            y++;

            // Campo: ¿Hospitalización?
            gbc.gridx = 0;
            gbc.gridy = y;
            add(new JLabel("¿Requirió hospitalización?"), gbc);

            JPanel panelHospital = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
            rdb_hospitalizacion_si = new JRadioButton("Sí");
            rdb_hospitalizacion_no = new JRadioButton("No");
            ButtonGroup bgHospital = new ButtonGroup();
            bgHospital.add(rdb_hospitalizacion_si);
            bgHospital.add(rdb_hospitalizacion_no);
            panelHospital.add(rdb_hospitalizacion_si);
            panelHospital.add(rdb_hospitalizacion_no);

            gbc.gridx = 1;
            add(panelHospital, gbc);
            y++;

            // Campo: Descripción de los hechos
            gbc.gridx = 0;
            gbc.gridy = y;
            gbc.anchor = GridBagConstraints.NORTHWEST;
            add(new JLabel("Descripción de los hechos:"), gbc);

            txt_descripcion = new JTextField(40);
            txt_descripcion.setPreferredSize(new Dimension(500, 100));
            gbc.gridx = 1;
            gbc.fill = GridBagConstraints.BOTH;
            add(txt_descripcion, gbc);


    }


    public void reset(){
          txt_victima.setText("");
          txt_agresor.setText("");
          cmb_relacionAgresor.setSelectedItem(0);
          txt_descripcion.setText("");

          rdb_agresores_si.setSelected(false);
          rdb_agresores_no.setSelected(false);
          rdb_testigos_si.setSelected(false);
          rdb_testigos_no.setSelected(false);
          txt_sintomas.setText("");
          rdb_hospitalizacion_si.setSelected(false);
          rdb_hospitalizacion_no.setSelected(false);
    }


    public String getVictima(){
        return txt_victima.getText();
    }

    public Boolean getAgresores(){
        return rdb_agresores_si.isSelected();
    }

    public String getAgresor(){
        return txt_agresor.getText();
    }

    public String getRelacionAgresor(){
        return (String)cmb_relacionAgresor.getSelectedItem();
    }

    public Boolean getTestigos(){
        return rdb_testigos_si.isSelected();
    }

    public String getSintomas(){
        return txt_sintomas.getText();
    }

    public Boolean getHospitalizacion(){
        return rdb_hospitalizacion_si.isSelected();
    }

    public String getDescripcion(){
        return txt_descripcion.getText();
    }
}
