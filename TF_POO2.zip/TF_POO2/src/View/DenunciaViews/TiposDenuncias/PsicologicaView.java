package View.DenunciaViews.TiposDenuncias;

import Controller.DenunciaControllers.TiposDenuncias.PsicologicaController;
import Interfaces.View;

import javax.swing.*;

public class PsicologicaView extends JPanel implements View {
    private PsicologicaController psicologicaController;

    private JTextField txt_victima;
    private JTextField txt_agresor;
    private JComboBox cmb_relacionAgresor;
    private JTextField txt_descripcion;

    private JComboBox cmb_frecuencia;
    private JTextField txt_sintomas;
    private JRadioButton rdb_hospitalizacion_si;
    private JRadioButton rdb_hospitalizacion_no;

    public PsicologicaView(PsicologicaController psicologicaController){
        this.psicologicaController = psicologicaController;

        iniciarComponentes();
    }

    @Override
    public void iniciarComponentes() {

    }

    private void make_frame(){

    }

    private void make_victima(){

    }

    private void make_agresor(){

    }

    private void make_relacionAgresor(){

    }

    private void make_descripcion(){

    }

    private void make_frecuencia(){

    }

    private void make_sintomas(){

    }

    private void hospitalizacion(){

    }

    public String getVictima(){
        return txt_victima.getText();
    }

    public String getAgresor(){
        return txt_agresor.getText();
    }

    public String getRelacionAgresor(){
        return (String)cmb_relacionAgresor.getSelectedItem();
    }

    public String getDescripcion(){
        return txt_descripcion.getText();
    }

    public String getFrecuencia(){
        return (String)cmb_frecuencia.getSelectedItem();
    }

    public String getSintomas(){
        return txt_sintomas.getText();
    }

    public Boolean getHospitalizacion(){
        return rdb_hospitalizacion_si.isSelected();
    }
}
