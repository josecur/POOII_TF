package Util.ubicacionDB;

public class Provincia {
    private String id;
    private String name;
    private String department_id;

    public Provincia(String id, String name, String department_id) {
        this.id = id;
        this.name = name;
        this.department_id = department_id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment_id() {
        return department_id;
    }

    public void setDepartment_id(String department_id) {
        this.department_id = department_id;
    }

    @Override
    public String toString() {
        return this.name;
    }

    public static Provincia fromString(String data){ //"1,Karen"

        String[] partes = data.split("-");

        return new Provincia(partes[0],partes[1],partes[2]);

    }
}
