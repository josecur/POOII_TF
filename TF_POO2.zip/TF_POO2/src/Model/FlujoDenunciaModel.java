package Model;


import Interfaces.Listener;
import Interfaces.Observable;
import Interfaces.TipoDenuncia;
import Util.Denuncia.DatosPersonales;
import Util.Denuncia.Denuncia;
import Util.Denuncia.DetallesDenuncia;
import Util.Denuncia.Ubicacion;

import java.util.ArrayList;
import java.util.List;

public class FlujoDenunciaModel implements Observable {
    private final List<Listener> listeners = new ArrayList<>();
    private TipoDenuncia tipoDenuncia;
    private DatosPersonales datosPersonales;
    private Ubicacion ubicacion;
    private DetallesDenuncia detallesDenuncia;
    private String id;

    public String getId() {

        return id;
    }

    public void setTipoDenuncia(TipoDenuncia tipoDenuncia) {
        this.tipoDenuncia = tipoDenuncia;
    }

    public void setDatosPersonales(DatosPersonales datosPersonales) {
        this.datosPersonales = datosPersonales;
    }

    public void setUbicacion(Ubicacion ubicacion) {
        this.ubicacion = ubicacion;
    }

    public void setId(String id) {
        this.id = id;
        notifyEvent("IDSET");
    }

    public void setDetallesDenuncia(DetallesDenuncia detallesDenuncia) {
        this.detallesDenuncia = detallesDenuncia;
    }


    public void limpiar() {
        datosPersonales = null;
        ubicacion = null;
        detallesDenuncia = null;
        tipoDenuncia = null;
        id = null;
    }

    public Denuncia construirDenunciaFinal() {
        return new Denuncia(detallesDenuncia, ubicacion, datosPersonales,tipoDenuncia);
    }



    @Override
    public void subscribe(Listener listener) {
        listeners.add(listener);
    }

    @Override
    public void unsubscribe(Listener listener) {
        listeners.remove(listener);
    }

    @Override
    public void notifyEvent(String evento) {
        for (Listener listener: listeners){
            listener.update(evento);
        }
    }
}
