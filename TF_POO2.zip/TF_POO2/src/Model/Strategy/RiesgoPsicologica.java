package Model.Strategy;

import Interfaces.NivelRiesgo;
import Interfaces.RiesgoBehavior;
import Util.Denuncia.Denuncia;
import Util.Denuncia.DetallesDenuncia;

public class RiesgoPsicologica implements RiesgoBehavior {
    @Override
    public NivelRiesgo evaluarRiesgo(Denuncia denuncia) {
        DetallesDenuncia detalles = denuncia.getDetallesDenuncia();

        boolean frecuenciaC = detalles.getFrecuencia().equals("Primera Vez") ||
                detalles.getFrecuencia().equals("Ocasionalmente");

        boolean frecuenciaE = detalles.getFrecuencia().equals("Frecuentemente") ||
                detalles.getFrecuencia().equals("Repetitivo");

        boolean ansiedad = detalles.getSintomas().equalsIgnoreCase("ansiedad");
        boolean depresion = detalles.getSintomas().equalsIgnoreCase("depresion");

        if (frecuenciaC){
            return NivelRiesgo.CRITICO;

        }else if (frecuenciaE || ansiedad || depresion) {
            return NivelRiesgo.EXTREMO;

        }

        return NivelRiesgo.ALTO;
    }
}
