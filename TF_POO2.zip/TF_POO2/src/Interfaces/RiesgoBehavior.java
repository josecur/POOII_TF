package Interfaces;

import Util.Denuncia.Denuncia;


public interface RiesgoBehavior {

    NivelRiesgo evaluarRiesgo(Denuncia denuncia);
}
