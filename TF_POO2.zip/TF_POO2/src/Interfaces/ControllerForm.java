package Interfaces;

public interface ControllerForm {
    void run();
}
