package Interfaces;

public enum TipoDenuncia {
    ABUSO_SEXUAL("Abuso Sexual"),
    ACOSO("Acoso"),
    ACOSO_SEXUAL("Acoso Sexual"),
    DOMESTICA("Violencia Doméstica"),
    PSICOLOGICA("Violencia Psicológica"),
    VIOLENCIA("Violencia");

    private String nombre;

    TipoDenuncia(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }
}

