package Interfaces;

public interface Observable {

    void suscribe();

    void unsuscribe();

    void notifyEvent();
}
