package Interfaces;

import Util.Denuncia.DetallesDenuncia;

public interface DenunciaFactory {
    DetallesDenuncia crearDenuncia();
}
