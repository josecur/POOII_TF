package Interfaces;

import Util.Denuncia.Denuncia;

public interface DenunciasRepository {

    void insertarDenuncia(Denuncia denuncia);

    String leerDenuncia(String idDenuncia);

    void actualizarDenuncia(Denuncia denuncia);

    void eliminarDenuncia(Denuncia denuncia);
}
