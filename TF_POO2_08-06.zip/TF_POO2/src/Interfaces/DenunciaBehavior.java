package Interfaces;

import Util.Denuncia.Denuncia;

public interface DenunciaBehavior {

    NivelRiesgo evaluarRiesgo(Denuncia denuncia);

    String generarResumenDenuncia(Denuncia denuncia);


}
