package Interfaces;

public interface ControllerForm {
    void run();

    void recolectarInfo();
}
