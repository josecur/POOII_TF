package Interfaces;

public enum NivelRiesgo {
    ALTO,
    CRITICO,
    EXTREMO
}
