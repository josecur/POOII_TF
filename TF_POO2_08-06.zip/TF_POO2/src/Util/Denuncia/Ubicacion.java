package Util.Denuncia;

import Util.ubicacionDB.Ubigeo;

public class Ubicacion {
    private Ubigeo ubigeo;
    private String direccion;
    private String detallesAdicionales;

    public Ubicacion(Ubigeo ubigeo, String direccion, String detallerAdicionales) {
        this.ubigeo = ubigeo;
        this.direccion = direccion;
        this.detallesAdicionales = detallerAdicionales;
    }

    public Ubigeo getUbicacionBd() {
            return ubigeo;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getDetallesAdicionales() {
        return detallesAdicionales;
    }

}
