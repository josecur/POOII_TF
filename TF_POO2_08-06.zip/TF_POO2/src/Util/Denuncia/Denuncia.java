package Util.Denuncia;

import Interfaces.DenunciaBehavior;
import Interfaces.NivelRiesgo;
import Interfaces.TipoDenuncia;

import java.util.Date;

public class Denuncia {
    private Date fechaSuceso;
    private String horaSuceso;

    private TipoDenuncia tipoDenuncia;

    private DatosPersonales datosPersonales;
    private Ubicacion ubicacion;
    private DetallesDenuncia detallesDenuncia;

    public Date getFechaSuceso() {
        return fechaSuceso;
    }

    public String getHoraSuceso() {
        return horaSuceso;
    }

    public TipoDenuncia getTipoDenuncia() {
        return tipoDenuncia;
    }

    public DatosPersonales getDatosPersonales() {
        return datosPersonales;
    }

    public Ubicacion getUbicacion() {
        return ubicacion;
    }

    public DetallesDenuncia getDetallesDenuncia() {
        return detallesDenuncia;
    }

    public void setFechaSuceso(Date fechaSuceso) {
        this.fechaSuceso = fechaSuceso;
    }

    public void setHoraSuceso(String horaSuceso) {
        this.horaSuceso = horaSuceso;
    }

    public void setTipoDenuncia(TipoDenuncia tipoDenuncia) {
        this.tipoDenuncia = tipoDenuncia;
    }

    public void setDatosPersonales(DatosPersonales datosPersonales) {
        this.datosPersonales = datosPersonales;
    }

    public void setUbicacion(Ubicacion ubicacion) {
        this.ubicacion = ubicacion;
    }

    public void setDetallesDenuncia(DetallesDenuncia detallesDenuncia) {
        this.detallesDenuncia = detallesDenuncia;
    }


}
