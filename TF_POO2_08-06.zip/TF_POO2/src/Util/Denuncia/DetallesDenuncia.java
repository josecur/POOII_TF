package Util.Denuncia;

import Model.DetallesDenunciaBuilder;

public class DetallesDenuncia {

    private String victima;
    private String agresor;
    private String relacionAgresor;
    private String medio;
    private boolean testigos;
    private String frecuencia;
    private boolean menoresInvolucrados;
    private String sintomas;
    private String duracionAproximada;
    private String heridas;
    private String gravedadHeridas;
    private boolean hospitalizacion;
    private boolean usoDeObjetos;
    private boolean medidasPrevias;
    private int agresores;
    private String objetos;
    private String descripcion;


    public DetallesDenuncia(DetallesDenunciaBuilder builder){
        this.victima = builder.victima;
        this.agresor = builder.agresor;
        this.relacionAgresor = builder.relacionAgresor;
        this.medio = builder.medio;
        this.testigos = builder.testigos;
        this.frecuencia = builder.frecuencia;
        this.menoresInvolucrados = builder.menoresInvolucrados;
        this.sintomas = builder.sintomas;
        this.duracionAproximada = builder.duracionAproximada;
        this.heridas = builder.heridas;
        this.gravedadHeridas = builder.gravedadHeridas;
        this.hospitalizacion = builder.hospitalizacion;
        this.usoDeObjetos = builder.usoDeObjetos;
        this.medidasPrevias = builder.medidasPrevias;
        this.agresores = builder.agresores;
        this.objetos = builder.objetos;
        this.descripcion = builder.descripcion;
    }

    public String getVictima() {
        return victima;
    }

    public String getAgresor() {
        return agresor;
    }

    public String getRelacionAgresor() {
        return relacionAgresor;
    }

    public String getMedio() {
        return medio;
    }

    public boolean isTestigos() {
        return testigos;
    }

    public String getFrecuencia() {
        return frecuencia;
    }

    public boolean isMenoresInvolucrados() {
        return menoresInvolucrados;
    }

    public String getSintomas() {
        return sintomas;
    }

    public String getDuracionAproximada() {
        return duracionAproximada;
    }

    public String getHeridas() {
        return heridas;
    }

    public String getGravedadHeridas() {
        return gravedadHeridas;
    }

    public boolean isHospitalizacion() {
        return hospitalizacion;
    }

    public boolean isUsoDeObjetos() {
        return usoDeObjetos;
    }

    public boolean isMedidasPrevias() {
        return medidasPrevias;
    }

    public int getAgresores() {
        return agresores;
    }

    public String getObjetos() {
        return objetos;
    }

    public String getDescripcion() {
        return descripcion;
    }
}
