package View;

import Controller.HomeController;
import Interfaces.Controller;
import Interfaces.View;

import javax.swing.*;
import java.awt.*;

public class HomeView extends JFrame implements View {
    private HomeController homeController;
    private CardLayout homeLayout;
    private JPanel contenedor;

    private final static int MAIN_FRAME_WIDTH = 1400;
    private final static int MAIN_FRAME_HEIGHT = 800;
    private final static int MAIN_FRAME_X = 100;
    private final static int MAIN_FRAME_Y = 100;

    public HomeView(HomeController homeController){
        this.homeController = homeController;

        iniciarComponentes();

        Controller.setLayout(homeLayout,contenedor);
    }


    @Override
    public void iniciarComponentes() {
        make_homeFrame();
        home_panel();
        agregarViews();
    }


    public void make_homeFrame() {

        setOpacity(1.0f);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(MAIN_FRAME_X, MAIN_FRAME_Y, MAIN_FRAME_WIDTH, MAIN_FRAME_HEIGHT);
        setMinimumSize(new Dimension(MAIN_FRAME_WIDTH, MAIN_FRAME_HEIGHT));
        setLocationRelativeTo(null);
        setResizable(false);

    }

    public void home_panel(){
        homeLayout = new CardLayout();
        contenedor = new JPanel(homeLayout);
        add(contenedor);
    }

    public void agregarViews(){
        addView("Pantalla Principal", homeController.getPrincipalView());
        addView("Terminos y Condiciones", homeController.getTerminosYCondicionesView());
        addView("Ubigeo", homeController.getUbigeoView());
        addView("Datos Personales",homeController.getDatosPersonalesView());
        addView("Denuncia Formulario",homeController.getDenunciaFormView());
        addView("Resumen Denuncia",homeController.getDenunciaResumenView());

    }

    public void addView(String name, JPanel view) {
        contenedor.add(view, name);
    }

}
