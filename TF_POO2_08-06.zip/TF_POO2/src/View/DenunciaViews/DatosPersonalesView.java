package View.DenunciaViews;

import Controller.DenunciaControllers.DatosPersonalesController;
import Interfaces.View;

import javax.swing.*;
import java.awt.*;

public class DatosPersonalesView extends JPanel implements View {
    private DatosPersonalesController datosPersonalesController;

    private JTextField txt_nombre;
    private JTextField txt_apellidoPaterno;
    private JTextField txt_apellidoMaterno;
    private JComboBox cmb_tipoDocumento;
    private JFormattedTextField txt_idDocumento;
    private JFormattedTextField txt_numeroCelular;
    private JTextField txt_email;
    private JFormattedTextField txt_edad;

    private JButton btn_siguiente;
    private JButton btn_atras;



    public DatosPersonalesView(DatosPersonalesController datosPersonalesController){
        this.datosPersonalesController = datosPersonalesController;

        iniciarComponentes();

    }


    @Override
    public void iniciarComponentes() {
        make_frame();
        make_nombreField();
        make_apellidoPaternoField();
        make_apellidoMaternoField();
        make_siguiente();
        make_atras();

    }

    private void make_frame() {
        setLayout(null);
    }

    private void make_nombreField(){

        JLabel lbl_nombre = new JLabel();
        lbl_nombre.setFont(new Font("Tahoma", Font.BOLD,40));
        lbl_nombre.setBounds(10,10,10,10);
        add(lbl_nombre);

        txt_nombre = new JTextField();
        txt_nombre.setFont(new Font("Tahoma",Font.BOLD,40));
        txt_nombre.setBounds(450,40,600,60);
        add(txt_nombre);

    }

    private void make_apellidoPaternoField(){

    }

    private void make_apellidoMaternoField(){

    }




    private void make_siguiente(){
        //Falta decoracion
        btn_siguiente = new JButton("Siguiente");

        btn_siguiente.addActionListener(e -> {
            datosPersonalesController.nextView();
        });

    }

    private void make_atras(){
        //Falta decoracion
        btn_atras = new JButton("Atras");

        btn_atras.addActionListener(e -> {
            datosPersonalesController.previousView();
        });

    }

    private void clear_fields(){

    }
}
