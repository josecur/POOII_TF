package View.DenunciaViews.TiposDenuncias;

import Controller.DenunciaControllers.TiposDenuncias.AbusoSexualController;
import Interfaces.View;

import javax.swing.*;

public class AbusoSexualView extends JPanel implements View {
    private AbusoSexualController abusoSexualController;


    private JTextArea txt_victima;
    private JTextArea txt_agresor;
    private JComboBox cmb_relacionAgresor;
    private JCheckBox chk_testigos;


    public AbusoSexualView(AbusoSexualController abusoSexualController){
        this.abusoSexualController = abusoSexualController;
    }

    @Override
    public void iniciarComponentes() {

    }

    private void make_frame(){

    }


}
