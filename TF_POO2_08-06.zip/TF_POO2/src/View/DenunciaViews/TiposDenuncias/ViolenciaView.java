package View.DenunciaViews.TiposDenuncias;

import Controller.DenunciaControllers.TiposDenuncias.ViolenciaController;
import Interfaces.View;

import javax.swing.*;

public class ViolenciaView extends JPanel implements View {
    private ViolenciaController violenciaController;

    public ViolenciaView(ViolenciaController violenciaController){
        this.violenciaController = violenciaController;
    }

    @Override
    public void iniciarComponentes() {

    }
}
