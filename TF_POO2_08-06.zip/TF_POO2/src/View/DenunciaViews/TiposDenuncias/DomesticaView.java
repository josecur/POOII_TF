package View.DenunciaViews.TiposDenuncias;

import Controller.DenunciaControllers.TiposDenuncias.DomesticaController;
import Interfaces.View;

import javax.swing.*;

public class DomesticaView extends JPanel implements View {
    private DomesticaController domesticaController;

    public DomesticaView(DomesticaController domesticaController){
        this.domesticaController = domesticaController;
    }

    @Override
    public void iniciarComponentes() {

    }
}
