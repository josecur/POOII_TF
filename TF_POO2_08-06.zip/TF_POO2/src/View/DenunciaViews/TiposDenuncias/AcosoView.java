package View.DenunciaViews.TiposDenuncias;

import Controller.DenunciaControllers.TiposDenuncias.AcosoController;
import Interfaces.View;

import javax.swing.*;

public class AcosoView extends JPanel implements View {
    private AcosoController acosoController;

    public AcosoView(AcosoController acosoController){
        this.acosoController = acosoController;
    }

    @Override
    public void iniciarComponentes() {

    }

}
