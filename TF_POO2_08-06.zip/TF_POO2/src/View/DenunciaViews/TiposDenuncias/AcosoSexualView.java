package View.DenunciaViews.TiposDenuncias;

import Controller.DenunciaControllers.TiposDenuncias.AcosoSexualController;
import Interfaces.View;

import javax.swing.*;

public class AcosoSexualView extends JPanel implements View {
    private AcosoSexualController acosoSexualController;

    public AcosoSexualView(AcosoSexualController acosoSexualController){
        this.acosoSexualController = acosoSexualController;
    }

    @Override
    public void iniciarComponentes() {

    }


}
