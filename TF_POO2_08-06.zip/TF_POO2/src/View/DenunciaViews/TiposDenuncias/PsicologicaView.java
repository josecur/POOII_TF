package View.DenunciaViews.TiposDenuncias;

import Controller.DenunciaControllers.TiposDenuncias.PsicologicaController;
import Interfaces.View;

import javax.swing.*;

public class PsicologicaView extends JPanel implements View {
    private PsicologicaController psicologicaController;

    public PsicologicaView(PsicologicaController psicologicaController){
        this.psicologicaController = psicologicaController;
    }

    @Override
    public void iniciarComponentes() {

    }
}
