package View.DenunciaViews;

import Controller.DenunciaControllers.DenunciaResumenController;
import Interfaces.View;

import javax.swing.*;
import java.awt.*;

public class DenunciaResumenView extends JPanel implements View {
    DenunciaResumenController denunciaResumenController;

    private JButton btn_siguiente;
    private JButton btn_atras;
    private JTextArea txtA_resumenArea;

    public DenunciaResumenView(DenunciaResumenController denunciaResumenController){
        this.denunciaResumenController = denunciaResumenController;

        iniciarComponentes();
    }

    @Override
    public void iniciarComponentes() {

    }

    private void make_resumenArea(){
        txtA_resumenArea = new JTextArea();
        txtA_resumenArea.setFont(new Font("Tahoma",Font.ITALIC,24));
        txtA_resumenArea.setLineWrap(true);
        txtA_resumenArea.setWrapStyleWord(true);
        txtA_resumenArea.setEditable(false);
        txtA_resumenArea.append(denunciaResumenController.getResumen(""));


        JScrollPane scrll_area = new JScrollPane(txtA_resumenArea);
        scrll_area.setBounds(200,120,1000,300);
        add(scrll_area);

    }

    private void clear_fields(){

    }

    private void make_siguiente(){
        //Falta decoracion
        btn_siguiente = new JButton("Siguiente");

        btn_siguiente.addActionListener(e -> {
            denunciaResumenController.nextView();
        });

    }

    private void make_atras(){
        //Falta decoracion
        btn_atras = new JButton("Atras");

        btn_atras.addActionListener(e -> {
            denunciaResumenController.previousView();
        });

    }
}
