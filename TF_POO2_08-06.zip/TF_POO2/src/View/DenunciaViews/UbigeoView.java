package View.DenunciaViews;

import Controller.DenunciaControllers.UbigeoController;
import Interfaces.View;
import Util.ubicacionDB.Departamento;
import Util.ubicacionDB.Distrito;
import Util.ubicacionDB.Provincia;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class UbigeoView extends JPanel implements View {
    private UbigeoController ubigeoController;
    private GridBagConstraints gbc;

    private JComboBox cmb_departamentos;
    private JComboBox cmb_provincias;
    private JComboBox cmb_distritos;
    private JTextField txt_direccion;
    private JTextField txt_detalles;
    private JButton btn_siguiente;
    private JButton btn_atras;


    public UbigeoView(UbigeoController ubigeoController){
        this.ubigeoController = ubigeoController;

        iniciarComponentes();

    }

    @Override
    public void iniciarComponentes() {
        make_frame();
        make_departamentos();
        make_provincias();
        make_distritos();
        make_direccion();
        make_detalles();
        make_siguiente();
        make_atras();

    }

    private void make_frame() {
        setLayout(new GridBagLayout());
        gbc = new GridBagConstraints();
    }

    private void cargarDepartamentos() {
        List<Departamento> departamentos = ubigeoController.fill_Departamentos();
        for (Departamento d : departamentos) {
            cmb_departamentos.addItem(d);
        }

    }

    private void cargarProvincias(String departamentoId) {
        List<Provincia> provincias = ubigeoController.fill_Provincias(departamentoId);
        for (Provincia p : provincias) {
            cmb_provincias.addItem(p);
        }

    }

    private void cargarDistritos(String provinciaId) {
        List<Distrito> distritos = ubigeoController.fill_Distritos(provinciaId);
        for (Distrito d : distritos) {
            cmb_distritos.addItem(d);
        }

    }

    //---------------------------------------------------------------------------------

    private void make_departamentos(){
        JLabel lbl = new JLabel("Departamento:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(lbl, gbc);

        cmb_departamentos = new JComboBox<>();
        gbc.gridx = 1;
        add(cmb_departamentos, gbc);

        cargarDepartamentos();

    }


    private void make_provincias(){
        JLabel lbl = new JLabel("Provincia:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(lbl, gbc);

        cmb_provincias = new JComboBox<>();
        gbc.gridx = 1;

        cmb_departamentos.addActionListener(e -> {
            cmb_provincias.removeAllItems();
            cmb_distritos.removeAllItems();
            Departamento seleccionado = (Departamento) cmb_departamentos.getSelectedItem();

            if (seleccionado != null) {
                cargarProvincias(seleccionado.getId());
            }

        });

        add(cmb_provincias, gbc);

    }

    private void make_distritos(){
        JLabel lbl = new JLabel("Distrito:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(lbl, gbc);

        cmb_distritos = new JComboBox<>();
        gbc.gridx = 1;


        cmb_provincias.addActionListener(e -> {
            cmb_distritos.removeAllItems();
            Provincia seleccionado = (Provincia) cmb_provincias.getSelectedItem();

            if (seleccionado != null) {
                cargarDistritos(seleccionado.getId());
            }

        });

        add(cmb_distritos, gbc);

    }

    private void make_direccion(){
        JLabel lbl = new JLabel("Dirección:");
        gbc.gridx = 0;
        gbc.gridy = 3;
        add(lbl, gbc);

        txt_direccion = new JTextField(20);
        gbc.gridx = 1;
        add(txt_direccion, gbc);

    }

    private void make_detalles(){
        JLabel lbl = new JLabel("Detalles Adicionales:");
        gbc.gridx = 0;
        gbc.gridy = 4;
        add(lbl, gbc);

        txt_detalles = new JTextField(20);
        gbc.gridx = 1;
        add(txt_detalles, gbc);
    }

    private void make_siguiente(){
        btn_siguiente = new JButton("Siguiente");
        btn_siguiente.setFont(new Font("Tahoma", Font.PLAIN, 16));

        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(10, 10, 20, 20);
        add(btn_siguiente, gbc);


        btn_siguiente.addActionListener(e -> {
            ubigeoController.nextView();
        });

    }

    private void make_atras(){
        btn_atras = new JButton("Atras");
        btn_atras.setFont(new Font("Tahoma", Font.PLAIN, 16));

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 20, 20, 10);
        add(btn_atras, gbc);

        btn_atras.addActionListener(e -> {
            ubigeoController.previousView();
        });

    }

    private void clear_fields(){

    }
}
