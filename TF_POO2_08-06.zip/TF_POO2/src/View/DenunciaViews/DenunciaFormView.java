package View.DenunciaViews;

import Controller.DenunciaControllers.DenunciaFormController;
import Interfaces.TipoDenuncia;
import Interfaces.View;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;

public class DenunciaFormView extends JPanel implements View {
    private DenunciaFormController denunciaFormController;

    private CardLayout cardLayout = new CardLayout();
    private JPanel panelDenuncia = new JPanel(cardLayout);
    JPanel panelSuperior = new JPanel(new FlowLayout());
    JPanel panelInferior = new JPanel(new FlowLayout());

    private JComboBox<String> cmb_TipoDenuncias;
    private JFormattedTextField txt_date;
    private JFormattedTextField txt_hour;
    private JButton btn_siguiente;
    private JButton btn_atras;

    public DenunciaFormView(DenunciaFormController denunciaFormController){
        this.denunciaFormController = denunciaFormController;

        iniciarComponentes();
    }


    @Override
    public void iniciarComponentes() {
        make_frame();

        make_superior();
        make_center();
        make_south();


    }

    private void make_frame() {
        setLayout(new BorderLayout());
    }

    private void make_superior(){
        panelSuperior.add(new JLabel("Tipo de Denuncia:"));
        make_tipoDenuncia();
        panelSuperior.add(new JLabel("Fecha:"));
        make_date();
        panelSuperior.add(new JLabel("Hora:"));
        make_hour();
        add(panelSuperior, BorderLayout.NORTH);
    }

    private void make_center(){
        make_panelDenuncia();
        agregarViews();
    }

    private void make_south(){
        make_atras();
        make_siguiente();
        add(panelInferior, BorderLayout.SOUTH);
    }

    private void agregarViews(){
        panelDenuncia.add(denunciaFormController.getAbusoSexualView(),TipoDenuncia.ABUSO_SEXUAL.name());
        panelDenuncia.add(denunciaFormController.getAcosoSexualView(),TipoDenuncia.ACOSO_SEXUAL.name());
        panelDenuncia.add(denunciaFormController.getAcosoView(), TipoDenuncia.ACOSO.name());
        panelDenuncia.add(denunciaFormController.getDomesticaView(), TipoDenuncia.DOMESTICA.name());
        panelDenuncia.add(denunciaFormController.getPsicologicaView(), TipoDenuncia.PSICOLOGICA.name());
        panelDenuncia.add(denunciaFormController.getViolenciaView(), TipoDenuncia.VIOLENCIA.name());

        cardLayout.show(panelDenuncia, TipoDenuncia.ABUSO_SEXUAL.name());

    }

    private void make_tipoDenuncia(){
        cmb_TipoDenuncias = new JComboBox<>();
        cmb_TipoDenuncias.setPrototypeDisplayValue("Violencia Psicológica");

        for(TipoDenuncia tipo : TipoDenuncia.values()){
            cmb_TipoDenuncias.addItem(tipo.getNombre());
        }

        panelSuperior.add(cmb_TipoDenuncias);

        cmb_TipoDenuncias.addActionListener(e -> {
            String txt = (String) cmb_TipoDenuncias.getSelectedItem();
            for (TipoDenuncia tipo : TipoDenuncia.values()) {
                if (tipo.getNombre().equals(txt)) {
                    cardLayout.show(panelDenuncia, tipo.name());
                    break;
                }
            }
        });
    }

    private void make_date(){
        try {
            MaskFormatter dateFormatter = new MaskFormatter("##-##-####"); // DD-MM-YYYY
            dateFormatter.setPlaceholderCharacter(' ');
            txt_date = new JFormattedTextField(dateFormatter);
            txt_date.setColumns(10);

            panelSuperior.add(txt_date);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void make_hour(){
        try {
            MaskFormatter hourFormatter = new MaskFormatter("##:##");
            hourFormatter.setPlaceholderCharacter(' ');
            txt_hour = new JFormattedTextField(hourFormatter);
            txt_hour.setColumns(5);

            panelSuperior.add(txt_hour);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void make_panelDenuncia(){
        add(panelDenuncia, BorderLayout.CENTER);

    }

    private void make_siguiente(){
        //Falta decoracion
        btn_siguiente = new JButton("Siguiente");
        btn_siguiente.setSize(200,200);
        panelInferior.add(btn_siguiente);


        btn_siguiente.addActionListener(e -> {
            denunciaFormController.nextView();
        });

    }

    private void make_atras(){
        //Falta decoracion
        btn_atras = new JButton("Atras");
        panelInferior.add(btn_atras);


        btn_atras.addActionListener(e -> {
            denunciaFormController.previousView();
        });

    }

    private void clear_fields(){

    }
}
