package View.DenunciaViews;

import Controller.DenunciaControllers.TerminosYCondicionesController;
import Interfaces.View;

import javax.swing.*;
import java.awt.*;

public class TerminosYCondicionesView extends JPanel implements View {
    private TerminosYCondicionesController terminosYCondicionesController;
    private GridBagConstraints gbc;


    private JCheckBox chk_aceptarTerminos;
    private JTextArea txtA_terminosArea;
    private JLabel lbl_titulo;

    private JButton btn_siguiente;
    private JButton btn_atras;

    public TerminosYCondicionesView(TerminosYCondicionesController terminosYCondicionesController){
        this.terminosYCondicionesController = terminosYCondicionesController;

        iniciarComponentes();
    }


    @Override
    public void iniciarComponentes() {

        make_frame();
        make_titulo();
        make_TerminosYCondiciones();
        make_checkbox();
        make_siguiente();
        make_atras();

    }


    private void make_frame() {
        setLayout(new GridBagLayout());
        gbc = new GridBagConstraints();
    }

    public void make_titulo(){
        lbl_titulo = new JLabel("Términos y Condiciones");
        lbl_titulo.setFont(new Font("Tahoma", Font.BOLD, 30));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 20, 20, 20);
        gbc.anchor = GridBagConstraints.CENTER;
        add(lbl_titulo, gbc);

    }

    public void make_TerminosYCondiciones(){
        txtA_terminosArea = new JTextArea(15, 60);
        txtA_terminosArea.setFont(new Font("Tahoma", Font.ITALIC, 18));
        txtA_terminosArea.setLineWrap(true);
        txtA_terminosArea.setWrapStyleWord(true);
        txtA_terminosArea.setEditable(false);
        txtA_terminosArea.setText(terminosYCondicionesController.leerDocumento());

        JScrollPane scroll = new JScrollPane(txtA_terminosArea);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(0, 20, 20, 20);
        add(scroll, gbc);

    }

    public void make_checkbox(){
        chk_aceptarTerminos = new JCheckBox("He leído y acepto los términos y condiciones");
        chk_aceptarTerminos.setFont(new Font("Tahoma", Font.PLAIN, 16));

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(10, 20, 10, 20);
        add(chk_aceptarTerminos, gbc);

        chk_aceptarTerminos.addActionListener(e -> {
            btn_siguiente.setEnabled(chk_aceptarTerminos.isSelected());
        });
    }


    private void make_siguiente(){
        btn_siguiente = new JButton("Siguiente");
        btn_siguiente.setFont(new Font("Tahoma", Font.PLAIN, 16));
        btn_siguiente.setEnabled(false);

        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(10, 10, 20, 20);
        add(btn_siguiente, gbc);

        btn_siguiente.addActionListener(e -> {
            terminosYCondicionesController.nextView();
        });

    }

    private void make_atras(){
        btn_atras = new JButton("Atras");
        btn_atras.setFont(new Font("Tahoma", Font.PLAIN, 16));

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 20, 20, 10);
        add(btn_atras, gbc);

        btn_atras.addActionListener(e -> {
            terminosYCondicionesController.previousView();
        });

    }

}
