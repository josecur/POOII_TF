package Model;

import java.util.Random;

public class IdGenerador {
    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final int ID_LENGTH = 8;



    public String generateRandomID() {
        StringBuilder sb = new StringBuilder(ID_LENGTH);
        Random random = new Random();
        for (int i = 0; i < ID_LENGTH; i++) {
            int index = random.nextInt(CHARACTERS.length());
            sb.append(CHARACTERS.charAt(index));
        }
        return sb.toString();
    }

    public String generarIdDenuncia(String departamentoId){
        StringBuilder sb = new StringBuilder();

        String abb = new UbicacionRepository().obtenerAbreviacionDepartamento(departamentoId);

        String siguiente = "a";

        sb.append("D-").append(abb).append("-").append(siguiente);

        return sb.toString();
    }

}
