package Model;

import Interfaces.UbigeoRepository;
import Util.ubicacionDB.DBConectionUbigeo;
import Util.ubicacionDB.Departamento;
import Util.ubicacionDB.Distrito;
import Util.ubicacionDB.Provincia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UbicacionRepository implements UbigeoRepository {

    @Override
    public List<Departamento> obtenerDepartamentos() {
        List<Departamento> listaDepartamentos = new ArrayList<>();
        String query = "SELECT * FROM ubigeo_peru_departments";

        try (Connection conn = DBConectionUbigeo.conectar();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("name");
                String abbreviation = rs.getString("abbreviation");
                listaDepartamentos.add(new Departamento(id, name, abbreviation));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return listaDepartamentos;
    }

    @Override
    public List<Provincia> obtenerProvinciasPorDepartamento(String departamentoId) {
        List<Provincia> listaProvincia = new ArrayList<>();
        String query = "SELECT * FROM ubigeo_peru_provinces WHERE department_id = ?";

        try (Connection conn = DBConectionUbigeo.conectar();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, departamentoId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String id = rs.getString("id");
                    String name = rs.getString("name");
                    String department_id = rs.getString("department_id");

                    listaProvincia.add(new Provincia(id, name, department_id));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return listaProvincia;
    }

    @Override
    public List<Distrito> obtenerDistritosPorProvincia(String provinciaId) {
        List<Distrito> listaDistrito = new ArrayList<>();
        String query = "SELECT * FROM ubigeo_peru_districts WHERE province_id = ?";

        try (Connection conn = DBConectionUbigeo.conectar();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, provinciaId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String id = rs.getString("id");
                    String name = rs.getString("name");
                    String province_id = rs.getString("province_id");
                    String department_id = rs.getString("department_id");

                    listaDistrito.add(new Distrito(id, name, province_id, department_id));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return listaDistrito;
    }

    @Override
    public String obtenerAbreviacionDepartamento(String departamentoId) {
        String abbreviation = null;
        String query = "SELECT abbreviation FROM ubigeo_peru_departments WHERE id = ?";

        try (Connection conn = DBConectionUbigeo.conectar();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, departamentoId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    abbreviation = rs.getString("abbreviation");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return abbreviation;
    }
}
