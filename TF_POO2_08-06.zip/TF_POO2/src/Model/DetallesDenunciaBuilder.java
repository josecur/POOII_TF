package Model;

import Util.Denuncia.DetallesDenuncia;

public class DetallesDenunciaBuilder {
    public String victima;
    public String agresor;
    public String relacionAgresor;
    public String medio;
    public boolean testigos;
    public String frecuencia;
    public boolean menoresInvolucrados;
    public String sintomas;
    public String duracionAproximada;
    public String heridas;
    public String gravedadHeridas;
    public boolean hospitalizacion;
    public boolean usoDeObjetos;
    public boolean medidasPrevias;
    public int agresores;
    public String objetos;
    public String descripcion;


    public DetallesDenunciaBuilder victima(String victima) {
        this.victima = victima;
        return this;
    }

    public DetallesDenunciaBuilder agresor(String agresor) {
        this.agresor = agresor;
        return this;
    }

    public DetallesDenunciaBuilder relacionAgresor(String relacionAgresor) {
        this.relacionAgresor = relacionAgresor;
        return this;
    }

    public DetallesDenunciaBuilder medio(String medio) {
        this.medio = medio;
        return this;
    }

    public DetallesDenunciaBuilder testigos(boolean testigos) {
        this.testigos = testigos;
        return this;
    }

    public DetallesDenunciaBuilder frecuencia(String frecuencia) {
        this.frecuencia = frecuencia;
        return this;
    }

    public DetallesDenunciaBuilder menoresInvolucrados(boolean menoresInvolucrados) {
        this.menoresInvolucrados = menoresInvolucrados;
        return this;
    }

    public DetallesDenunciaBuilder sintomas(String sintomas) {
        this.sintomas = sintomas;
        return this;
    }

    public DetallesDenunciaBuilder duracionAproximada(String duracionAproximada) {
        this.duracionAproximada = duracionAproximada;
        return this;
    }

    public DetallesDenunciaBuilder heridas(String heridas) {
        this.heridas = heridas;
        return this;
    }

    public DetallesDenunciaBuilder gravedadHeridas(String gravedadHeridas) {
        this.gravedadHeridas = gravedadHeridas;
        return this;
    }

    public DetallesDenunciaBuilder hospitalizacion(boolean hospitalizacion) {
        this.hospitalizacion = hospitalizacion;
        return this;
    }

    public DetallesDenunciaBuilder usoDeObjetos(boolean usoDeObjetos) {
        this.usoDeObjetos = usoDeObjetos;
        return this;
    }

    public DetallesDenunciaBuilder medidasPrevias(boolean medidasPrevias) {
        this.medidasPrevias = medidasPrevias;
        return this;
    }

    public DetallesDenunciaBuilder agresores(int agresores) {
        this.agresores = agresores;
        return this;
    }

    public DetallesDenunciaBuilder objetos(String objetos) {
        this.objetos = objetos;
        return this;
    }

    public DetallesDenunciaBuilder descripcion(String descripcion) {
        this.descripcion = descripcion;
        return this;
    }

    public DetallesDenuncia build(){
        return new DetallesDenuncia(this);
    }
}
