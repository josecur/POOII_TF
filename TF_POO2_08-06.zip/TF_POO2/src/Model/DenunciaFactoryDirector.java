package Model;

import Interfaces.DenunciaFactory;
import Interfaces.TipoDenuncia;
import Model.DetallesDenunciaFactory.*;

import java.util.HashMap;
import java.util.Map;

public class DenunciaFactoryDirector {
    private Map<TipoDenuncia, DenunciaFactory> factories = new HashMap<>();

    public DenunciaFactoryDirector() {
        factories.put(TipoDenuncia.DOMESTICA, new DomesticaFactory());
        factories.put(TipoDenuncia.VIOLENCIA, new ViolenciaFactory());
        factories.put(TipoDenuncia.PSICOLOGICA, new PsicologicaFactory());
        factories.put(TipoDenuncia.ABUSO_SEXUAL, new AbusoSexualFactory());
        factories.put(TipoDenuncia.ACOSO, new AcosoFactory());
        factories.put(TipoDenuncia.ACOSO_SEXUAL, new AcosoSexualFactory());
    }


}
