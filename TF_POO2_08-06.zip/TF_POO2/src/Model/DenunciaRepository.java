package Model;

import Interfaces.DenunciasRepository;
import Util.Denuncia.DBConectionDenuncias;
import Util.Denuncia.Denuncia;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DenunciaRepository implements DenunciasRepository {


    @Override
    public void insertarDenuncia(Denuncia denuncia) {

        String query = "INSERT ------ ";

        try{
            Connection conn = DBConectionDenuncias.conectar();
            PreparedStatement ps = conn.prepareStatement(query);

            ps.setString(1,denuncia.getDatosPersonales().getNombre());



        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public String leerDenuncia(String idDenuncia) {
        String mensaje = null;
        String query = "{EXEC sp_getMensajeDenuncia ?}";

        try (Connection conn = DBConectionDenuncias.conectar();
            CallableStatement ps = conn.prepareCall(query)) {

            ps.setString(1, idDenuncia);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                mensaje = rs.getString("mensaje");
            }

        }catch (Exception e){
            e.printStackTrace();
        }

        return mensaje;

    }

    @Override
    public void actualizarDenuncia(Denuncia denuncia) {

        String query = "";

        try{
            Connection conn = DBConectionDenuncias.conectar();
            PreparedStatement ps = conn.prepareStatement(query);

            ResultSet rs = ps.executeQuery();





        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public void eliminarDenuncia(Denuncia denuncia) {

        String query = "";

        try{
            Connection conn = DBConectionDenuncias.conectar();
            PreparedStatement ps = conn.prepareStatement(query);

            ResultSet rs = ps.executeQuery();



        }catch (Exception e){
            e.printStackTrace();
        }

    }
}
