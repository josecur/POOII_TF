package Model.DetallesDenunciaFactory;

import Interfaces.DenunciaFactory;
import Model.DetallesDenunciaBuilder;
import Util.Denuncia.DetallesDenuncia;

public class PsicologicaFactory implements DenunciaFactory {
    @Override
    public DetallesDenuncia crearDenuncia() {
        return new DetallesDenunciaBuilder()

                .build();
    }
}
