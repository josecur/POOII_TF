package Model.DetallesDenunciaFactory;

import Interfaces.DenunciaFactory;
import Model.DetallesDenunciaBuilder;
import Util.Denuncia.DetallesDenuncia;

public class DomesticaFactory implements DenunciaFactory {
    @Override
    public DetallesDenuncia crearDenuncia() {
        return new DetallesDenunciaBuilder()

                .build();
    }

}
