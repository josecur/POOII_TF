package Controller.DenunciaControllers;

import Controller.DenunciaControllers.TiposDenuncias.*;
import Interfaces.Controller;
import View.DenunciaViews.DenunciaFormView;
import View.DenunciaViews.TiposDenuncias.*;

public class DenunciaFormController extends Controller {
    DenunciaFormView denunciaFormView;

    AbusoSexualController abusoSexualController = new AbusoSexualController();
    AcosoSexualController acosoSexualController = new AcosoSexualController();
    AcosoController acosoController = new AcosoController();
    DomesticaController domesticaController = new DomesticaController();
    PsicologicaController psicologicaController = new PsicologicaController();
    ViolenciaController violenciaController = new ViolenciaController();



    @Override
    public void run() {
        denunciaFormView = new DenunciaFormView(this);


    }

    public void recolectarDatos(){

    }



    public void nextView(){
        changeView("Resumen Denuncia");
    }

    public void previousView(){
        changeView("Ubigeo");
    }

    public DenunciaFormView getView() {
        return denunciaFormView;
    }

    public AbusoSexualView getAbusoSexualView() { return abusoSexualController.getView();}
    public AcosoSexualView getAcosoSexualView() { return acosoSexualController.getView();}
    public AcosoView getAcosoView() { return acosoController.getView();}
    public DomesticaView getDomesticaView() { return domesticaController.getView();}
    public PsicologicaView getPsicologicaView() { return psicologicaController.getView(); }
    public ViolenciaView getViolenciaView() { return violenciaController.getView(); }


}
