package Controller.DenunciaControllers.TiposDenuncias;

import Interfaces.ControllerForm;
import View.DenunciaViews.TiposDenuncias.AcosoView;

public class AcosoController implements ControllerForm {
    @Override
    public void run() {

    }

    @Override
    public void recolectarInfo() {

    }

    public AcosoView getView(){
        return new AcosoView(this);
    }
}
