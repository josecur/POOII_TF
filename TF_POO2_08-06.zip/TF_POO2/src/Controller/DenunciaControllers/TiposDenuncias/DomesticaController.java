package Controller.DenunciaControllers.TiposDenuncias;

import Interfaces.ControllerForm;
import View.DenunciaViews.TiposDenuncias.DomesticaView;

public class DomesticaController implements ControllerForm {
    @Override
    public void run() {

    }

    @Override
    public void recolectarInfo() {

    }

    public DomesticaView getView(){
        return new DomesticaView(this);
    }
}
