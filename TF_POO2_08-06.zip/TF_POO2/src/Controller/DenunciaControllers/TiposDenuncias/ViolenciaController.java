package Controller.DenunciaControllers.TiposDenuncias;

import Interfaces.ControllerForm;
import View.DenunciaViews.TiposDenuncias.ViolenciaView;

public class ViolenciaController implements ControllerForm {
    @Override
    public void run() {

    }

    @Override
    public void recolectarInfo() {

    }

    public ViolenciaView getView(){
        return new ViolenciaView(this);
    }
}
