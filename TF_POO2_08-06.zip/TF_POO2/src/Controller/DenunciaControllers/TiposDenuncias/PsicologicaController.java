package Controller.DenunciaControllers.TiposDenuncias;

import Interfaces.ControllerForm;
import View.DenunciaViews.TiposDenuncias.PsicologicaView;

public class PsicologicaController implements ControllerForm {
    @Override
    public void run() {

    }

    @Override
    public void recolectarInfo() {

    }

    public PsicologicaView getView(){
        return new PsicologicaView(this);
    }
}
