package Controller.DenunciaControllers.TiposDenuncias;

import Interfaces.ControllerForm;
import View.DenunciaViews.TiposDenuncias.AcosoSexualView;

public class AcosoSexualController implements ControllerForm {

    @Override
    public void run() {

    }

    @Override
    public void recolectarInfo() {

    }

    public AcosoSexualView getView(){
        return new AcosoSexualView(this);
    }
}
