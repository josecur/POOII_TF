package Controller.DenunciaControllers.TiposDenuncias;

import Interfaces.ControllerForm;
import View.DenunciaViews.TiposDenuncias.AbusoSexualView;

public class AbusoSexualController implements ControllerForm {
    private AbusoSexualView abusoSexualView;


    @Override
    public void run() {

    }

    @Override
    public void recolectarInfo() {

    }

    public AbusoSexualView getView(){
        return new AbusoSexualView(this);
    }
}
