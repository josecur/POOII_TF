package Controller.DenunciaControllers;

import Interfaces.Controller;
import Model.DenunciaRepository;
import View.DenunciaViews.DenunciaResumenView;

public class DenunciaResumenController extends Controller {
    private DenunciaRepository denunciaRepository = new DenunciaRepository();
    private DenunciaResumenView denunciaResumenView;


    @Override
    public void run() {
        denunciaResumenView = new DenunciaResumenView(this);
    }

    public String getResumen(String idDenuncia){
        return denunciaRepository.leerDenuncia(idDenuncia);
    }

    public void nextView(){
        changeView("");
    }

    public void previousView(){
        changeView("Denuncia Formulario");
    }

    public DenunciaResumenView getView() {
        return denunciaResumenView;
    }
}
