package Controller.DenunciaControllers;

import Interfaces.Controller;

import Model.UbicacionRepository;
import Util.ubicacionDB.Departamento;
import Util.ubicacionDB.Distrito;
import Util.ubicacionDB.Provincia;
import View.DenunciaViews.UbigeoView;

import java.util.List;

public class UbigeoController extends Controller {
    private UbicacionRepository ubicacionRepository = new UbicacionRepository();;
    private UbigeoView ubigeoView;



    @Override
    public void run() {
        ubigeoView = new UbigeoView(this);

    }

    public List<Departamento> fill_Departamentos(){
        return ubicacionRepository.obtenerDepartamentos();
    }

    public List<Provincia> fill_Provincias(String idDepartamento){
        return ubicacionRepository.obtenerProvinciasPorDepartamento(idDepartamento);
    }

    public List<Distrito> fill_Distritos(String idProvincia){
        return ubicacionRepository.obtenerDistritosPorProvincia(idProvincia);
    }

    public void recolectarDatos(){

    }

    public void nextView(){
        changeView("Denuncia Formulario");
    }

    public void previousView(){
        changeView("Datos Personales");
    }


    public UbigeoView getView() {
        return ubigeoView;
    }
}
