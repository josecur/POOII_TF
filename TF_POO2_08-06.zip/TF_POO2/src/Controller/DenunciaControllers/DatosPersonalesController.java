package Controller.DenunciaControllers;

import Interfaces.Controller;
import View.DenunciaViews.DatosPersonalesView;


public class DatosPersonalesController extends Controller {
    private DatosPersonalesView datosPersonalsView;

    @Override
    public void run() {
        datosPersonalsView = new DatosPersonalesView(this);

    }


    public void recolectarDatos(){

    }


    public void nextView(){
        changeView("Ubigeo");
    }

    public void previousView(){
        changeView("Terminos y Condiciones");
    }


    public DatosPersonalesView getView() {
        return datosPersonalsView;
    }
}
