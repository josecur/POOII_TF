package Controller;

import Controller.DenunciaControllers.*;
import Interfaces.Controller;
import View.DenunciaViews.*;
import View.HomeView;
import View.PrincipalView;

import javax.swing.*;
import java.util.HashMap;
import java.util.Map;


public class HomeController extends Controller {
    private HomeView homeView;
    private Map<String, JPanel> views = new HashMap<>();

    private TerminosYCondicionesController terminosYCondicionesController = new TerminosYCondicionesController();
    private UbigeoController ubigeoController = new UbigeoController();
    private DatosPersonalesController datosPersonalesController = new DatosPersonalesController();
    private DenunciaFormController denunciaFormController = new DenunciaFormController();
    private DenunciaResumenController denunciaResumenController = new DenunciaResumenController();


    private PrincipalController principalController = new PrincipalController();



    @Override
    public void run() {
        terminosYCondicionesController.run();
        principalController.run();
        ubigeoController.run();
        datosPersonalesController.run();
        denunciaFormController.run();
        denunciaResumenController.run();
        

        HomeView homeView = new HomeView(this);
        homeView.setVisible(true);

        setPrincipalView();
    }

    public void setPrincipalView(){
        changeView("Ubigeo");
    }

    public TerminosYCondicionesView getTerminosYCondicionesView(){
        return terminosYCondicionesController.getView();
    }

    public UbigeoView getUbigeoView(){
        return ubigeoController.getView();
    }

    public PrincipalView getPrincipalView(){
        return principalController.getView();
    }

    public DatosPersonalesView getDatosPersonalesView(){
        return datosPersonalesController.getView();
    }

    public DenunciaFormView getDenunciaFormView(){ return denunciaFormController.getView(); }

    public DenunciaResumenView getDenunciaResumenView(){ return denunciaResumenController.getView(); }



}

